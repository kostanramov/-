# Воспроизведение исследования TCP и HTTP

В комплекте находятся эталоны, PCAP T00–T05, T06, сохранённые выходы
tcpflow и ngrep, исходники и результаты проверки. Учётные данные тестовые.
Работа с PCAP выполняется офлайн.

## 1. Состав и происхождение

- reference — исходные файлы, восемь сообщений HTTP, credentials.json и manifest.json.
- pcaps — исходные T00–T05 и созданный из T00 сценарий T06.
- results/tcpflow/T00..T05 — сохранённые результаты исходного опыта на ALT.
- results/ngrep/T00..T05 — сохранённые совпавшие пакеты и метаданные исходного опыта.
- results/*/T06_snaplen — контрольный офлайн-прогон 
- analysis — CSV, JSON, покрытие и результаты отрицательных контролей.
- logs — актуальные журналы проверки.
- scripts — исполняемые исходники описанной в курсовой процедуры.
- provenance — первоначальные версии скриптов, таблиц и журналов.
- analysis/verification_context.json и CHANGES.md — среда повторной проверки и изменения.

Основная серия ALT даёт 23/24 точных объекта после tcpflow и прикладного разбора,
20/24 полных шаблонов ngrep. T06_snaplen даёт 1/4 точных артефактов и 3/4 полных
шаблонов в отдельном контрольном прогоне. Эти показатели имеют разные единицы.

## 2. Проверка приложенных результатов без запуска утилит

Python 3.10+ и стандартная библиотека достаточны. Перейдите в tcp-forensics
после распаковки архива и выполните последовательно.

```bash
(cd reference && sha256sum -c hashes.sha256)
(cd pcaps && sha256sum -c pcaps.sha256)
(cd pcaps && sha256sum -c T06_snaplen.pcap.sha256)
python3 scripts/verify_reference.py
python3 scripts/verify_tcpflow.py
python3 scripts/verify_ngrep.py
python3 scripts/check_t06_snaplen.py
python3 scripts/verify_t06_snaplen_tools.py --debug
python3 scripts/audit_saved_artifacts.py
python3 scripts/check_verifier.py
python3 scripts/compare_with_tcpflow.py
```

Проверка заново создаёт производные analysis и объекты из сохранённых raw-потоков.
Исходные reference и PCAP сохраняют свои байты.

Полный перечень файлов с хешами находится в комплекте evidence_manifest.json.
Его контрольная сумма записана в evidence_manifest.sha256.

## 3. Заново выполнить утилиты на отдельной копии

Понадобятся tcpflow, ngrep, Python и Scapy 2.5.0. Установите пакеты для своей ОС.
Версии каждого нового прогона сохраняйте вместе с результатами.

Создайте соседний каталог, который ещё не существует, и скопируйте туда комплект.

```bash
test ! -e ../tcp-forensics-rerun && cp -a . ../tcp-forensics-rerun
cd ../tcp-forensics-rerun
mv results results_saved
mkdir results
python3 scripts/run_tcpflow.py
python3 scripts/verify_tcpflow.py
python3 scripts/run_ngrep.py
python3 scripts/verify_ngrep.py
python3 scripts/validate_pcaps.py
python3 scripts/check_t06_snaplen.py
python3 scripts/run_t06_snaplen_tools.py
python3 scripts/verify_t06_snaplen_tools.py --debug
python3 scripts/audit_saved_artifacts.py
python3 scripts/check_verifier.py
```

run_tcpflow.py и run_ngrep.py защищены от смешения старых и новых результатов.
При иной версии утилиты сравните метаданные и зафиксируйте фактический результат.

## 4. Проверить генерацию эталонов и PCAP с нуля

Создайте отдельный пустой проект. Копируются только исходники.

```bash
test ! -e ../tcp-forensics-generated && mkdir ../tcp-forensics-generated
cp -a scripts ../tcp-forensics-generated/
cd ../tcp-forensics-generated
python3 scripts/prepare_reference.py
python3 scripts/verify_reference.py
python3 scripts/generate_pcaps.py
python3 scripts/validate_pcaps.py
python3 scripts/make_t06_snaplen.py
python3 scripts/check_t06_snaplen.py
(cd reference && sha256sum -c hashes.sha256)
python3 scripts/run_tcpflow.py
python3 scripts/verify_tcpflow.py
python3 scripts/run_ngrep.py
python3 scripts/verify_ngrep.py
python3 scripts/run_t06_snaplen_tools.py
python3 scripts/verify_t06_snaplen_tools.py --debug
python3 scripts/audit_saved_artifacts.py
```

Для сравнения с опубликованным набором используйте pcaps/pcaps.sha256 из исходного
комплекта. В контрольной проверке Scapy 2.5.0 все эталоны и шесть PCAP T00–T05
получились побайтово идентичными. Текст Host внутри эталонного HTTP равен
10.77.10.20:8080. IP-заголовки моделируемого обмена содержат 192.168.56.10 и
192.168.56.20. Host является неизменным значением тестовых данных.

Исторический параметр generate_pcaps.py --only T06 относится к IP-фрагментации.
Для snaplen применяются только make_t06_snaplen.py и имя T06_snaplen.


