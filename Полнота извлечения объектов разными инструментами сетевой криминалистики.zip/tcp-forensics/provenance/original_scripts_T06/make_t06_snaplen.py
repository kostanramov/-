#!/usr/bin/env python3
"""Generate T06 snaplen-truncated PCAP directly from immutable T00.pcap.

No reserialization of network frames. Each packet record keeps original_len,
TCP sequence numbers, timestamps and the first min(snaplen,len) frame bytes.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from t06_pcap import (ROOT,PCAPS,REF,SRC,OUT,META,SNAPLEN_DEFAULT,FLOW_INFO,
                       read_pcap,write_pcap,PcapRecord,sha256,tcp_view,detect_endpoints,
                       selected_packet)


def run():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--snaplen',type=int,default=SNAPLEN_DEFAULT)
    p.add_argument('--source',type=Path,default=SRC)
    p.add_argument('--output',type=Path,default=OUT)
    p.add_argument('--force',action='store_true',help='Explicitly replace only this T06_snaplen output and metadata')
    args=p.parse_args()
    src=args.source.resolve()
    out=args.output.resolve()
    if out.name!='T06_snaplen.pcap':
        raise ValueError('Output must be named T06_snaplen.pcap to avoid overwriting old T06 (IPv4 fragments)')
    if out==src:
        raise ValueError('Output may not overwrite source')
    if args.snaplen<128 or args.snaplen>65535:
        raise ValueError('Use 128..65535. Recommended: 256. Verification requires 256 for the reference experiment.')
    info=out.with_suffix('.json')
    sums=out.with_suffix(out.suffix+'.sha256')
    if not args.force and any(f.exists() for f in (out,info,sums)):
        raise FileExistsError('Output exists. Use --force only when you intentionally repeat T06 snaplen test.')
    input_pcap=read_pcap(src)
    if any(r.captured_len!=r.original_len for r in input_pcap.records):
        raise ValueError('Source T00 already contains truncated records; need full baseline for valid comparison')
    if args.snaplen>=input_pcap.snaplen:
        raise ValueError('New snaplen must be smaller than source global snaplen')
    srcinfo=src.with_suffix('.json')
    if srcinfo.exists():
        source_meta=json.loads(srcinfo.read_text(encoding='utf-8'))
        if source_meta.get('pcap_sha256')!=sha256(src):
            raise ValueError('Source T00.pcap does not match saved T00.json SHA-256')
    manifest=REF/'manifest.json'
    if not manifest.exists():
        raise FileNotFoundError('Missing reference/manifest.json from step 2')
    manifest_dict=json.loads(manifest.read_text(encoding='utf-8'))
    for artifact in manifest_dict.get('artifacts',[]):
        path=REF/artifact['path']
        if not path.is_file() or path.stat().st_size!=artifact['bytes'] or sha256(path)!=artifact['sha256']:
            raise ValueError(f'Reference object changed: {path}')
    sender,analyzer=detect_endpoints(input_pcap)
    truncated=[]
    for r in input_pcap.records:
        n=min(r.captured_len,args.snaplen)
        truncated.append(PcapRecord(r.time1,r.time2,n,r.original_len,r.data[:n]))
    if sum(r.captured_len<r.original_len for r in truncated)==0:
        raise ValueError('No packets exceed snaplen. Choose a smaller snaplen.')
    # Explicitly guarantee headers survive and the T00 four target flows are present.
    by_case={k: {'packets':0,'original_payload':0,'captured_payload':0} for k in FLOW_INFO}
    for old,new in zip(input_pcap.records,truncated):
        original=tcp_view(old.data)
        sliced=tcp_view(new.data)
        if original and not sliced:
            raise ValueError('Snaplen lost a TCP header; select a larger snaplen')
        if original and sliced:
            for k in by_case:
                if selected_packet(original,k,sender,analyzer):
                    by_case[k]['packets']+=1
                    by_case[k]['original_payload']+=len(original.payload)
                    by_case[k]['captured_payload']+=len(sliced.payload)
    if any(not x['original_payload'] for x in by_case.values()):
        raise ValueError('Source lacks one or more of four reference HTTP messages')
    if args.snaplen==256 and all(x['original_payload']==x['captured_payload'] for x in by_case.values()):
        raise ValueError('No target HTTP payload was truncated')
    out.parent.mkdir(parents=True, exist_ok=True)
    write_pcap(out,input_pcap,args.snaplen,truncated)
    detail={
        'scenario':'T06','scenario_variant':'snaplen_truncation',
        'description':'Snapshot-length truncation of existing T00 records; no packet omitted',
        'source_pcap':str(src.relative_to(ROOT)) if src.is_relative_to(ROOT) else str(src),
        'source_pcap_sha256':sha256(src),
        'pcap_sha256':sha256(out),
        'reference_manifest_sha256':sha256(manifest),
        'sender_ip':sender,'analyzer_ip':analyzer,'server_port':8080,
        'snaplen_bytes':args.snaplen,'source_snaplen_bytes':input_pcap.snaplen,
        'source_packet_count':len(input_pcap.records),
        'output_packet_count':len(truncated),
        'truncated_packets':sum(r.captured_len<r.original_len for r in truncated),
        'payload_stats':by_case,
        'note':'The packet record original_len and headers are preserved; only captured_len and saved bytes are reduced.',
    }
    info.write_text(json.dumps(detail,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    sums.write_text(f"{detail['pcap_sha256']}  {out.name}\n",encoding='ascii')
    print('PASS: generated',out)
    print(f'  original T00 packets: {len(input_pcap.records)}; new packets: {len(truncated)}')
    print(f'  snaplen: {input_pcap.snaplen} -> {args.snaplen}')
    print(f"  truncated packet records: {detail['truncated_packets']}")
    print(f'  sender={sender}, analyzer={analyzer}, port=8080')
    print('  SHA256:',detail['pcap_sha256'])
    print('  Metadata:',info)
    print('  Checksum:',sums)

if __name__=='__main__':
    try: run()
    except (OSError,ValueError,KeyError,AssertionError) as e:
        print('ERROR:',e,file=sys.stderr)
        sys.exit(2)
