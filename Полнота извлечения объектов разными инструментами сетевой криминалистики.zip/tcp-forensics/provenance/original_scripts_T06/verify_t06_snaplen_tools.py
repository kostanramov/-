#!/usr/bin/env python3
"""Audit tcpflow objects and ngrep per-packet matches in T06_snaplen only.

Independently compare recovered HTTP bytes against step-2 reference.
Never treat ngrep matched packets as a reconstructed HTTP object.
"""
from __future__ import annotations
import argparse
import base64
from collections import Counter
import csv
import hashlib
import ipaddress
import json
from pathlib import Path
import re
import sys
from urllib.parse import parse_qs
from t06_pcap import (ROOT,REF,RESULTS,OUT,META,ANALYSIS,FLOW_INFO,
                       read_pcap,tcp_view,detect_endpoints,selected_packet,sha256)

FLOW_RE=re.compile(r'(?P<src>\d{1,3}(?:\.\d{1,3}){3})\.(?P<sport>\d{1,5})-'
                   r'(?P<dst>\d{1,3}(?:\.\d{1,3}){3})\.(?P<dport>\d{1,5})')
T_CSV=['scenario','object_id','flow_present','raw_stream_exact','http_headers_complete',
       'content_length_expected','recovered_body_bytes','expected_body_bytes',
       'file_sha256_exact','credentials_exact','object_exact','file_name','problem']
N_CSV=['scenario','object_id','full_pattern','matched_packets','expected_matches_from_captured_payload',
       'ngrep_exit_code','packet_audit_pass','note']


def save_csv(file,rows,fields):
    with file.open('w',newline='',encoding='utf-8') as stream:
        w=csv.DictWriter(stream,fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def endpoint_file(path:Path):
    m=FLOW_RE.search(path.name)
    if not m:
        return None
    try:
        return (str(ipaddress.IPv4Address('.'.join(str(int(x)) for x in m['src'].split('.')))),int(m['sport']),
                str(ipaddress.IPv4Address('.'.join(str(int(x)) for x in m['dst'].split('.')))),int(m['dport']))
    except ValueError:
        return None


def tcpflow_files(folder:Path):
    seen={}
    for f in folder.glob('*'):
        if not f.is_file() or f.name=='report.xml' or f.name.endswith(('.findx','-HTTP','-HTTPBODY')):
            continue
        ep=endpoint_file(f)
        if ep:
            seen.setdefault(ep,[]).append(f)
    return seen


def messages():
    creds=json.loads((REF/'credentials.json').read_text(encoding='utf-8'))
    basic_token=base64.b64encode(f"{creds['basic']['username']}:{creds['basic']['password']}".encode('ascii'))
    return creds,{
        'small':b'FILE_START_MARKER_SMALL',
        'large':b'FILE_START_MARKER_LARGE',
        'post':('password='+creds['form']['password']).encode('ascii'),
        'basic':b'Authorization: Basic '+basic_token,
    }


def verify():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--debug',action='store_true')
    args=cli.parse_args()
    meta=json.loads(META.read_text(encoding='utf-8'))
    if meta.get('scenario_variant')!='snaplen_truncation' or sha256(OUT)!=meta['pcap_sha256']:
        raise ValueError('T06_snaplen PCAP hash/metadata mismatch')
    source=read_pcap(OUT)
    sender,analyzer=detect_endpoints(source)
    if (sender,analyzer)!=(meta['sender_ip'],meta['analyzer_ip']):
        raise ValueError('IP metadata mismatch')
    tcp_root=RESULTS/'tcpflow'/'T06_snaplen'
    ng_root=RESULTS/'ngrep'/'T06_snaplen'
    if not (tcp_root/'run_metadata.json').is_file() or not (ng_root/'run_metadata.json').is_file():
        raise FileNotFoundError('Run scripts/run_t06_snaplen_tools.py first')
    run=json.loads((tcp_root/'run_metadata.json').read_text(encoding='utf-8'))
    if run['pcap_sha256']!=meta['pcap_sha256']:
        raise ValueError('Instrument output tied to a different PCAP')
    creds,patterns=messages()
    indexed=tcpflow_files(tcp_root/'raw')
    if args.debug:
        print('Detected Sender/Analyzer:',sender,analyzer)
        print('Identified tcpflow endpoints:')
        for key,files in sorted(indexed.items()):
            print(' ',key, [x.name for x in files])
    objects_dir=tcp_root/'objects'
    objects_dir.mkdir(parents=True,exist_ok=True)
    trows=[]
    nrows=[]
    for case,(port,direction,httpfile,objname) in FLOW_INFO.items():
        ipkey=(sender,port,analyzer,8080) if direction=='request' else (analyzer,8080,sender,port)
        streams=indexed.get(ipkey,[])
        original=(REF/'http'/httpfile).read_bytes()
        result={k:'' for k in T_CSV}
        result.update(scenario='T06_snaplen',object_id=objname,flow_present=len(streams)==1,
                      raw_stream_exact=False,http_headers_complete=False,
                      file_sha256_exact='',credentials_exact='',object_exact=False,
                      expected_body_bytes='',recovered_body_bytes='',
                      file_name=streams[0].name if len(streams)==1 else '',problem='')
        if len(streams)==1:
            actual=streams[0].read_bytes()
            result['raw_stream_exact']=(actual==original)
            head,delim,body=actual.partition(b'\r\n\r\n')
            if delim:
                result['http_headers_complete']=True
                length_match=re.search(br'(?im)^Content-Length:\s*(\d+)\s*$',head)
                expected_length=int(length_match.group(1)) if length_match else None
                result['content_length_expected']=expected_length if expected_length is not None else ''
                result['recovered_body_bytes']=len(body)
                if case in ('small','large'):
                    expected=(REF/objname).read_bytes()
                    result['expected_body_bytes']=len(expected)
                    result['file_sha256_exact']=hashlib.sha256(body).digest()==hashlib.sha256(expected).digest()
                    result['object_exact']=(body==expected)
                    artifact=objects_dir/(objname if result['object_exact'] else objname+'.unverified')
                    artifact.write_bytes(body)
                    if not result['object_exact']:
                        result['problem']=f'HTTP body differs from reference (saved {len(body)} of {len(expected)} bytes; file may include gaps/fillers)'
                elif case=='post':
                    try:
                        fields=parse_qs(body.decode('ascii'),strict_parsing=True,keep_blank_values=True)
                        ok=(fields=={'username':[creds['form']['username']],'password':[creds['form']['password']]})
                    except (ValueError,UnicodeError):
                        ok=False
                    result['object_exact']=ok
                    result['credentials_exact']=ok
                    if not ok:
                        result['problem']='POST values differ from reference or message incomplete'
                else:
                    m=re.search(br'(?im)^Authorization:\s*Basic\s+(\S+)\s*$',head)
                    try:
                        val=base64.b64decode(m.group(1),validate=True).decode('ascii') if m else ''
                        ok=val==f"{creds['basic']['username']}:{creds['basic']['password']}"
                    except (ValueError,UnicodeError,base64.binascii.Error):
                        ok=False
                    result['object_exact']=ok
                    result['credentials_exact']=ok
                    if not ok:
                        result['problem']='Basic credentials differ from reference or header incomplete'
                if expected_length is not None and expected_length!=len(body):
                    result['problem']=(result['problem']+'; ' if result['problem'] else '')+f'Content-Length={expected_length}, recovered={len(body)}'
            else:
                result['problem']='No complete HTTP header separator in tcpflow output'
        else:
            result['problem']=f'Expected one raw flow, found {len(streams)}'
        trows.append(result)
        pattern=patterns[case]
        expected_frames=[r.data for r in source.records if (p:=tcp_view(r.data)) and selected_packet(p,case,sender,analyzer) and pattern in p.payload]
        raw_matches=ng_root/case/'full_matched.pcap'
        if raw_matches.is_file():
            selected=[r.data for r in read_pcap(raw_matches).records]
        else:
            selected=[]
        ng=run['ngrep'][case]
        equal=(Counter(selected)==Counter(expected_frames))
        rc=ng['return_code']
        if not equal or rc!=(0 if expected_frames else 1):
            raise ValueError(f'ngrep {case}: matched packet set/return code differs from expected per-packet search; code={rc}, got={len(selected)}, expected={len(expected_frames)}')
        nrows.append({'scenario':'T06_snaplen','object_id':objname,'full_pattern':pattern.decode('ascii'),
                      'matched_packets':len(selected),'expected_matches_from_captured_payload':len(expected_frames),
                      'ngrep_exit_code':rc,'packet_audit_pass':True,
                      'note':'Matches over each truncated packet payload only; not HTTP file reconstruction'})
        print(f"{case:5s}: tcpflow exact={str(result['object_exact']):5s}; ngrep matches={len(selected)}; lost-by-snaplen depends on packet sizes")
    ANALYSIS.mkdir(parents=True,exist_ok=True)
    tfile=ANALYSIS/'T06_snaplen_tcpflow.csv'
    nfile=ANALYSIS/'T06_snaplen_ngrep.csv'
    save_csv(tfile,trows,T_CSV)
    save_csv(nfile,nrows,N_CSV)
    summary={'scenario':'T06_snaplen','pcap_sha256':meta['pcap_sha256'],
             'snaplen_bytes':source.snaplen,
             'tcpflow_exact_objects':sum(bool(r['object_exact']) for r in trows),
             'ngrep_objects_with_full_pattern':sum(r['matched_packets']>0 for r in nrows),
             'tcpflow':trows,'ngrep':nrows,
             'methodology_note':'ngrep only detects full patterns within individual captured packet payloads; SHA256 object reconstruction evaluated only for tcpflow'}
    sfile=ANALYSIS/'T06_snaplen_results.json'
    sfile.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PASS: verification of T06 tool outputs completed')
    print('Saved:',tfile,nfile,sfile)

if __name__=='__main__':
    try:verify()
    except (OSError,ValueError,KeyError,IndexError) as e:
        print('ERROR:',e,file=sys.stderr)
        sys.exit(2)
