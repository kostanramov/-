#!/usr/bin/env python3
"""Independent PCAP-level proof of T06 snapshot truncation. No Scapy needed."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from collections import Counter
from t06_pcap import (ROOT,SRC,OUT,META,REF,FLOW_INFO,
                       read_pcap,sha256,tcp_view,detect_endpoints,selected_packet)


def run():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=SRC)
    parser.add_argument('--pcap',type=Path,default=OUT)
    parser.add_argument('--metadata',type=Path,default=META)
    args=parser.parse_args()
    source=read_pcap(args.source)
    target=read_pcap(args.pcap)
    data=json.loads(args.metadata.read_text(encoding='utf-8'))
    if data.get('scenario_variant')!='snaplen_truncation':
        raise ValueError('Metadata identifies a different T06 scenario')
    if sha256(args.source)!=data['source_pcap_sha256']:
        raise ValueError('Source T00 hash changed')
    if sha256(args.pcap)!=data['pcap_sha256']:
        raise ValueError('Truncated T06 PCAP hash changed')
    if sha256(REF/'manifest.json')!=data['reference_manifest_sha256']:
        raise ValueError('Reference manifest was changed')
    if source.timestamp_unit!=target.timestamp_unit or source.endian!=target.endian:
        raise ValueError('PCAP timestamp resolution or endianness changed')
    if source.linktype!=target.linktype or len(source.records)!=len(target.records):
        raise ValueError('Linktype or number of packets changed')
    if target.snaplen!=data['snaplen_bytes']:
        raise ValueError('Global PCAP snaplen was not set correctly')
    # Check all bytes, incl_len, orig_len, time stamps and TCP headers.
    changed=0
    for i,(s,t) in enumerate(zip(source.records,target.records),1):
        if s.captured_len!=s.original_len:
            raise ValueError(f'Source record {i} was already truncated')
        if (s.time1,s.time2,s.original_len)!=(t.time1,t.time2,t.original_len):
            raise ValueError(f'Record {i}: timestamps/original_len changed')
        if t.captured_len!=min(s.captured_len,target.snaplen):
            raise ValueError(f'Record {i}: incl_len is not min(original_len, snaplen)')
        if t.data!=s.data[:t.captured_len]:
            raise ValueError(f'Record {i}: bytes do not match exact original packet prefix')
        if t.captured_len<t.original_len:
            changed+=1
        old=tcp_view(s.data)
        new=tcp_view(t.data)
        if old and not new:
            raise ValueError(f'Record {i}: TCP header was truncated')
        if old and new:
            if (old.src,old.dst,old.sport,old.dport,old.sequence)!=(new.src,new.dst,new.sport,new.dport,new.sequence):
                raise ValueError(f'Record {i}: TCP header differs')
    if not changed:
        raise ValueError('No records actually truncated')
    if changed!=data['truncated_packets']:
        raise ValueError('Metadata truncated record count differs')
    sender,analyzer=detect_endpoints(target)
    if (sender,analyzer)!=(data['sender_ip'],data['analyzer_ip']):
        raise ValueError('Lab endpoints changed')
    # Assert that each direction still starts with a complete HTTP header.
    directions={}
    for rec in target.records:
        t=tcp_view(rec.data)
        if t is None or not t.payload:
            continue
        for k,(port,_,httpname,_) in FLOW_INFO.items():
            if selected_packet(t,k,sender,analyzer):
                directions.setdefault(k,t.payload)
            # Also validate the opposite direction for each port.
            if t.sport==port and t.dst==analyzer and t.dport==8080:
                directions.setdefault('request_'+str(port),t.payload)
            if t.sport==8080 and t.dst==sender and t.dport==port:
                directions.setdefault('response_'+str(port),t.payload)
    for port in (41001,41002,41003,41004):
        for direction in ('request','response'):
            key=f'{direction}_{port}'
            if key not in directions or b'\r\n\r\n' not in directions[key]:
                raise ValueError(f'HTTP headers not fully present in first payload of {key}')
    payload_audit=[]
    for k,(port,direction,_,_) in FLOW_INFO.items():
        full=[tcp_view(r.data) for r in source.records]
        cut=[tcp_view(r.data) for r in target.records]
        orig_sum=sum(len(q.payload) for q in full if q and selected_packet(q,k,sender,analyzer))
        cap_sum=sum(len(q.payload) for q in cut if q and selected_packet(q,k,sender,analyzer))
        payload_audit.append({'object':k,'direction':direction,'port':port,'original_payload_bytes':orig_sum,'saved_payload_bytes':cap_sum,'missing_due_to_snaplen':orig_sum-cap_sum})
    if not any(x['missing_due_to_snaplen']>0 for x in payload_audit):
        raise ValueError('No HTTP payload was actually truncated')
    result={
        'status':'PASS','scenario':'T06_snaplen','snaplen':target.snaplen,
        'packet_count':len(target.records),'truncated_packet_count':changed,
        'headers_preserved':True,
        'all_original_packet_lengths_preserved':True,
        'all_tcp_sequence_numbers_preserved':True,
        'input_sha256':sha256(args.source),'output_sha256':sha256(args.pcap),
        'by_object':payload_audit,
    }
    path=ROOT/'analysis'/'T06_snaplen_capture_audit.json'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'PASS: all T00 packets preserved; packet bytes cut only at snaplen={target.snaplen}')
    print(f'  total packet records: {len(target.records)}')
    print(f'  records with incl_len < orig_len: {changed}')
    print(f'  all TCP/IP and HTTP headers retained: yes')
    print(f'  sender={sender}, analyzer={analyzer}')
    for row in payload_audit:
        print(f"  {row['object']:5s}: payload {row['saved_payload_bytes']}/{row['original_payload_bytes']} bytes saved; lost={row['missing_due_to_snaplen']}")
    print('  audit file:',path)

if __name__=='__main__':
    try:run()
    except (OSError,ValueError,KeyError,AssertionError) as e:
        print('ERROR:',e,file=sys.stderr); sys.exit(2)
