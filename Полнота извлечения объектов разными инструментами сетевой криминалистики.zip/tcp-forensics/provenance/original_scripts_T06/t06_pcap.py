#!/usr/bin/env python3
"""Classic PCAP (not PCAPNG) I/O and minimal Ethernet/IPv4/TCP parsing.

Standard library only. A truncated IP packet remains truncated: no attempt is made
 to repair IP total length, checksums, or TCP payload. No TCP reassembly here.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib
import ipaddress
import struct

ROOT = Path(__file__).resolve().parent.parent
PCAPS = ROOT / 'pcaps'
REF = ROOT / 'reference'
RESULTS = ROOT / 'results'
ANALYSIS = ROOT / 'analysis'
SRC = PCAPS / 'T00.pcap'
OUT = PCAPS / 'T06_snaplen.pcap'
META = PCAPS / 'T06_snaplen.json'
SNAPLEN_DEFAULT = 256
FLOW_INFO = {
  'small': (41001, 'response', 'response_small.http', 'small.txt'),
  'large': (41002, 'response', 'response_large.http', 'large.bin'),
  'post':  (41003, 'request',  'post_credentials.http', 'form_credentials'),
  'basic': (41004, 'request', 'get_basic.http', 'basic_credentials'),
}


def sha256(path: Path) -> str:
    dig = hashlib.sha256()
    with path.open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            dig.update(chunk)
    return dig.hexdigest()


@dataclass(frozen=True)
class PcapRecord:
    time1: int
    time2: int
    captured_len: int
    original_len: int
    data: bytes


@dataclass(frozen=True)
class PcapData:
    raw_header: bytes
    endian: str
    timestamp_unit: str
    snaplen: int
    linktype: int
    records: tuple[PcapRecord, ...]


def read_pcap(path: Path) -> PcapData:
    magic_map = {
        bytes.fromhex('d4c3b2a1'): ('<','us'),
        bytes.fromhex('a1b2c3d4'): ('>','us'),
        bytes.fromhex('4d3cb2a1'): ('<','ns'),
        bytes.fromhex('a1b23c4d'): ('>','ns'),
    }
    with path.open('rb') as f:
        header = f.read(24)
        if len(header) != 24 or header[:4] not in magic_map:
            raise ValueError(f'{path}: expected classic .pcap, not pcapng or a damaged file')
        endian, time_unit = magic_map[header[:4]]
        major, minor = struct.unpack_from(endian+'HH',header,4)
        if (major,minor) != (2,4):
            raise ValueError(f'{path}: unsupported PCAP version {major}.{minor}')
        snaplen, linktype = struct.unpack_from(endian+'II',header,16)
        if (linktype & 0xffff) != 1:
            raise ValueError(f'{path}: expected Ethernet linktype 1, got {linktype}')
        records=[]
        while True:
            rh=f.read(16)
            if not rh:
                break
            if len(rh)!=16:
                raise ValueError(f'{path}: truncated packet record header')
            t1,t2,cap,orig=struct.unpack(endian+'IIII',rh)
            if cap>orig or cap>16*1024*1024 or cap>snaplen:
                raise ValueError(f'{path}: invalid packet record (caplen={cap}, len={orig}, snaplen={snaplen})')
            b=f.read(cap)
            if len(b)!=cap:
                raise ValueError(f'{path}: packet data ends early')
            records.append(PcapRecord(t1,t2,cap,orig,b))
        if not records:
            raise ValueError(f'{path}: no packets')
    return PcapData(header,endian,time_unit,snaplen,linktype,tuple(records))


def write_pcap(path: Path, source: PcapData, snaplen: int, records: list[PcapRecord]):
    h=bytearray(source.raw_header)
    struct.pack_into(source.endian+'I',h,16,snaplen)
    with path.open('wb') as f:
        f.write(h)
        for p in records:
            f.write(struct.pack(source.endian+'IIII',p.time1,p.time2,p.captured_len,p.original_len))
            f.write(p.data)


@dataclass(frozen=True)
class TCPView:
    src: str
    dst: str
    sport: int
    dport: int
    sequence: int
    payload: bytes
    payload_offset: int
    packet_ip_total_len: int
    header_fully_captured: bool


def tcp_view(frame: bytes) -> TCPView | None:
    """Parse TCP header despite truncated payload; reject truncated header."""
    if len(frame)<14:
        return None
    ether_type=int.from_bytes(frame[12:14],'big')
    pos=14
    for _ in range(2):
        if ether_type not in (0x8100,0x88a8):
            break
        if len(frame)<pos+4:
            return None
        ether_type=int.from_bytes(frame[pos+2:pos+4],'big')
        pos+=4
    if ether_type!=0x0800 or len(frame)<pos+20:
        return None
    ip=frame[pos:]
    if ip[0]>>4 !=4:
        return None
    ihl=(ip[0]&15)*4
    if ihl<20 or len(ip)<ihl or ip[9]!=6:
        return None
    flags_off=int.from_bytes(ip[6:8],'big')
    if flags_off & 0x3fff:
        return None
    total_len=int.from_bytes(ip[2:4],'big')
    if total_len<ihl+20 or len(ip)<ihl+20:
        return None
    t=ip[ihl:]
    offset=(t[12]>>4)*4
    if offset<20 or len(t)<offset:
        return None
    data_start=pos+ihl+offset
    data_end=min(len(frame),pos+total_len)
    payload=frame[data_start:data_end]
    return TCPView(
        str(ipaddress.IPv4Address(ip[12:16])),
        str(ipaddress.IPv4Address(ip[16:20])),
        int.from_bytes(t[0:2],'big'),int.from_bytes(t[2:4],'big'),
        int.from_bytes(t[4:8],'big'),payload,data_start,total_len,True,
    )


def detect_endpoints(data: PcapData) -> tuple[str,str]:
    pairs=set()
    for record in data.records:
        pkt=tcp_view(record.data)
        if pkt is None:
            continue
        if pkt.sport in (41001,41002,41003,41004) and pkt.dport==8080:
            pairs.add((pkt.src,pkt.dst))
        elif pkt.sport==8080 and pkt.dport in (41001,41002,41003,41004):
            pairs.add((pkt.dst,pkt.src))
    if len(pairs)!=1:
        raise ValueError(f'Cannot uniquely infer Sender/Analyzer from TCP endpoints: {sorted(pairs)}')
    return next(iter(pairs))


def selected_packet(pkt: TCPView, case: str, sender: str, analyzer: str) -> bool:
    port,direction,_,_=FLOW_INFO[case]
    if direction=='request':
        return (pkt.src,pkt.sport,pkt.dst,pkt.dport)==(sender,port,analyzer,8080)
    return (pkt.src,pkt.sport,pkt.dst,pkt.dport)==(analyzer,8080,sender,port)
