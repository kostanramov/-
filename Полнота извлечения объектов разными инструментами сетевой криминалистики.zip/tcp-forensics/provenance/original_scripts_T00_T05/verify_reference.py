#!/usr/bin/env python3
"""Verify object bytes, SHA-256, HTTP/1.1 framing and synthetic credentials."""
from pathlib import Path
from urllib.parse import urlencode
import base64
import hashlib
import json

BASE = Path(__file__).resolve().parent.parent
REF = BASE / "reference"
HTTP = REF / "http"
manifest = json.loads((REF / "manifest.json").read_text(encoding="utf-8"))
creds = json.loads((REF / "credentials.json").read_text(encoding="utf-8"))

for item in manifest["artifacts"]:
    data = (REF / item["path"]).read_bytes()
    assert len(data) == item["bytes"], item["path"] + ": wrong size"
    assert hashlib.sha256(data).hexdigest() == item["sha256"], item["path"] + ": hash mismatch"
    print("PASS", item["path"], len(data), "bytes")

small = (REF / "small.txt").read_bytes()
large = (REF / "large.bin").read_bytes()
assert len(small) == 128 and small.startswith(b"FILE_START_MARKER_SMALL\n")
assert len(large) == 65536 and large.startswith(b"FILE_START_MARKER_LARGE\n")
assert small.endswith(b"\nFILE_END_MARKER_SMALL\n")
assert large.endswith(b"\nFILE_END_MARKER_LARGE\n")


def split_http(filename):
    raw = (HTTP / filename).read_bytes()
    header, marker, body = raw.partition(b"\r\n\r\n")
    assert marker == b"\r\n\r\n", filename + ": header separator missing"
    lines = header.split(b"\r\n")
    assert lines[0].endswith(b"HTTP/1.1") or lines[0].startswith(b"HTTP/1.1 ")
    field_map = {}
    for line in lines[1:]:
        key, separator, value = line.partition(b":")
        assert separator == b":" and key, filename + ": malformed header"
        field_map[key.strip().lower()] = value.strip()
    if b"content-length" in field_map:
        assert int(field_map[b"content-length"]) == len(body), filename + ": Content-Length mismatch"
    else:
        assert body == b"", filename + ": body without Content-Length"
    assert b"transfer-encoding" not in field_map, filename + ": unexpected transfer encoding"
    return lines[0], field_map, body


assert split_http("response_small.http")[2] == small
assert split_http("response_large.http")[2] == large
for name in ("get_small.http", "get_large.http", "get_basic.http"):
    assert split_http(name)[2] == b""

start, fields, body = split_http("post_credentials.http")
assert start.startswith(b"POST /login HTTP/1.1")
assert body == urlencode([("username", creds["form"]["username"]), ("password", creds["form"]["password"])]).encode("ascii")
assert b"password=TEST_SECRET_2026" in body

start, fields, body = split_http("get_basic.http")
auth_header = fields[b"authorization"]
assert auth_header.startswith(b"Basic ")
plain = base64.b64decode(auth_header[6:], validate=True).decode("ascii")
assert plain == f'{creds["basic"]["username"]}:{creds["basic"]["password"]}'
assert split_http("response_post.http")[2] == b"OK\n"
assert split_http("response_basic.http")[2] == b"OK\n"
print("PASS: HTTP framing, Content-Length and credential values")
print("PASS: all reference integrity checks")
