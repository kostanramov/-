#!/usr/bin/env python3
"""Generate deterministic reference objects and canonical HTTP/1.1 messages."""
from pathlib import Path
from urllib.parse import urlencode
import base64
import hashlib
import json

BASE = Path(__file__).resolve().parent.parent
REF = BASE / "reference"
HTTP = REF / "http"

if (REF / "manifest.json").exists():
    raise SystemExit("ERROR: reference/manifest.json already exists. Reference data were not overwritten.")

HTTP.mkdir(parents=True, exist_ok=True)

SMALL_START = b"FILE_START_MARKER_SMALL\n"
SMALL_END = b"\nFILE_END_MARKER_SMALL\n"
small = SMALL_START + b"A" * (128 - len(SMALL_START) - len(SMALL_END)) + SMALL_END
assert len(small) == 128
(REF / "small.txt").write_bytes(small)

LARGE_START = b"FILE_START_MARKER_LARGE\n"
LARGE_END = b"\nFILE_END_MARKER_LARGE\n"
needed = 65536 - len(LARGE_START) - len(LARGE_END)
seed = b"tcp-forensics-largebin-v1:"
chunks = []
for counter in range((needed + 31) // 32):
    chunks.append(hashlib.sha256(seed + counter.to_bytes(8, "big")).digest())
large = LARGE_START + b"".join(chunks)[:needed] + LARGE_END
assert len(large) == 65536
(REF / "large.bin").write_bytes(large)

credentials = {
    "basic": {"username": "labuser", "password": "LabPass_2026"},
    "form": {"username": "labuser", "password": "TEST_SECRET_2026"},
    "notice": "Synthetic credentials; not for real accounts",
}
(REF / "credentials.json").write_text(
    json.dumps(credentials, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
    encoding="utf-8",
)

HOST = "10.77.10.20:8080"


def request(method: str, path: str, extra_headers=(), body: bytes = b"") -> bytes:
    headers = [
        f"{method} {path} HTTP/1.1",
        f"Host: {HOST}",
        "User-Agent: tcp-forensics-lab/1.0",
        *extra_headers,
        "Connection: close",
    ]
    if body:
        headers.append(f"Content-Length: {len(body)}")
    return ("\r\n".join(headers) + "\r\n\r\n").encode("ascii") + body


def response(body: bytes, content_type: str) -> bytes:
    headers = [
        "HTTP/1.1 200 OK",
        f"Content-Type: {content_type}",
        f"Content-Length: {len(body)}",
        "Connection: close",
    ]
    return ("\r\n".join(headers) + "\r\n\r\n").encode("ascii") + body


form_body = urlencode(credentials["form"]).encode("ascii")
basic_plain = f'{credentials["basic"]["username"]}:{credentials["basic"]["password"]}'
basic_token = base64.b64encode(basic_plain.encode("ascii")).decode("ascii")

messages = {
    "get_small.http": request("GET", "/small.txt"),
    "response_small.http": response(small, "text/plain"),
    "get_large.http": request("GET", "/large.bin"),
    "response_large.http": response(large, "application/octet-stream"),
    "post_credentials.http": request(
        "POST", "/login", ("Content-Type: application/x-www-form-urlencoded",), form_body
    ),
    "response_post.http": response(b"OK\n", "text/plain"),
    "get_basic.http": request("GET", "/auth-check", (f"Authorization: Basic {basic_token}",)),
    "response_basic.http": response(b"OK\n", "text/plain"),
}
for name, payload in messages.items():
    (HTTP / name).write_bytes(payload)

artifacts = [Path("small.txt"), Path("large.bin"), Path("credentials.json")]
artifacts.extend(Path("http") / filename for filename in sorted(messages))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = {
    "dataset_version": "tcp-forensics-v1",
    "description": "Deterministic ground truth for TCP flow and packet search comparison",
    "host": HOST,
    "artifacts": [
        {"path": p.as_posix(), "bytes": (REF / p).stat().st_size, "sha256": sha256(REF / p)}
        for p in artifacts
    ],
}
(REF / "manifest.json").write_text(
    json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
    encoding="utf-8",
)

with (REF / "hashes.sha256").open("w", encoding="ascii") as out:
    for p in artifacts + [Path("manifest.json")]:
        out.write(f"{sha256(REF / p)}  {p.as_posix()}\n")

print("Reference objects and HTTP messages created in:", REF)
print(f"small.txt: {len(small)} bytes")
print(f"large.bin: {len(large)} bytes")
print(f"POST body: {len(form_body)} bytes, {form_body.decode('ascii')}")
print(f"Basic Authorization token: {basic_token}")
print("Run: (cd reference && sha256sum -c hashes.sha256)")
