#!/usr/bin/env python3
"""Stage 5. Offline ngrep experiments: one search per object and scenario.

All probes use literal ASCII expressions (also valid regexes) and exact
BPF port/direction filters. -O writes matching PACKETS, not reconstructed files.
No PCAP or reference object is ever modified.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

from ngrep_lab import BASE, PCAPS, OUT, SCENARIOS, bpf, get_tests, metadata, parse_scenarios


def perform(command: list[str], where: Path, prefix: str) -> int:
    result = subprocess.run(command, text=True, encoding='utf-8', errors='replace', capture_output=True)
    (where / f'{prefix}.txt').write_text(result.stdout, encoding='utf8')
    (where / f'{prefix}.stderr.txt').write_text(result.stderr, encoding='utf8')
    if result.returncode not in (0, 1):
        raise RuntimeError(f'ngrep failed, rc={result.returncode}, command={command!r}; see {where}/{prefix}.stderr.txt')
    return result.returncode


def main() -> int:
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--scenarios', default=','.join(SCENARIOS))
    cli.add_argument('--ngrep', default=None, help='Full path to ngrep, if not in PATH')
    cli.add_argument('--skip-payload-dumps', action='store_true', help='Skip optional T02/T04 hex dumps')
    args = cli.parse_args()
    try:
        scenarios = parse_scenarios(args.scenarios)
        tests = get_tests()
        executable = args.ngrep or shutil.which('ngrep')
        if not executable:
            raise ValueError('ngrep executable not found; install it or specify --ngrep /usr/local/bin/ngrep')
        # Verify all selected files BEFORE writing any results.
        for scenario in scenarios:
            metadata(scenario)
            folder = OUT / scenario
            if folder.exists() and any(folder.iterdir()):
                raise ValueError(f'{folder} exists and is nonempty; rename it for a clean reproducible rerun')
        OUT.mkdir(parents=True, exist_ok=True)
        version_run = subprocess.run([executable, '-V'], capture_output=True, text=True, errors='replace')
        version = (version_run.stdout + version_run.stderr).strip()
        print('ngrep:', version or '(no version output)')
        for scenario in scenarios:
            target = OUT / scenario
            target.mkdir(parents=True, exist_ok=True)
            source = PCAPS / f'{scenario}.pcap'
            info = metadata(scenario)
            entries = []
            for test in tests:
                folder = target / test.key
                folder.mkdir()
                for label, pattern in [('full', test.full),
                                       *([('left', test.left), ('right', test.right)] if scenario == 'T02' else [])]:
                    filename = folder / f'{label}_matched.pcap'
                    command = [executable, '-q', '-I', str(source), '-W', 'byline',
                               '-O', str(filename), pattern.decode('ascii'), bpf(test)]
                    code = perform(command, folder, label)
                    entries.append({'object_id': test.object_id, 'test':label, 'pattern':pattern.decode('ascii'),
                                    'exit_code':code, 'bpf':bpf(test), 'command':command,
                                    'matched_pcap':str(filename.relative_to(BASE))})
                    print(f'{scenario} {test.key:<5} {label:<5}: return_code={code}')
            if scenario in ('T02', 'T04') and not args.skip_payload_dumps:
                dump_folder = target / 'raw_hex_dumps'
                dump_folder.mkdir()
                for test in tests:
                    command = [executable, '-q', '-x', '-I', str(source), '', bpf(test)]
                    perform(command, dump_folder, test.key)
                print(f'{scenario}: saved hexadecimal views of packet payloads')
            (target / 'run_metadata.json').write_text(json.dumps({
                'scenario': scenario, 'ngrep_version': version,
                'pcap_sha256': info['pcap_sha256'],
                'sender_ip': info['sender_ip'], 'analyzer_ip': info['analyzer_ip'],
                'timestamp_utc': datetime.now(timezone.utc).isoformat(),
                'runs': entries,
            }, indent=2, ensure_ascii=False) + '\n', encoding='utf8')
        print('DONE: outputs saved in results/ngrep/T00..T05 (no reference or PCAP files changed)')
        return 0
    except (ValueError, RuntimeError, FileNotFoundError) as exc:
        print('ERROR:', exc, file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
