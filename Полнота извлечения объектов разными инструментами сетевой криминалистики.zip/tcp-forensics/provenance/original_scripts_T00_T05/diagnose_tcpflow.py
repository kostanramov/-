#!/usr/bin/env python3
"""Read-only diagnosis for stage 4: locate missing tcpflow raw files and parse failures.

Use on Analyzer from any directory: python3 scripts/diagnose_tcpflow.py
It never modifies reference/, pcaps/, or tcpflow results.
"""
from pathlib import Path
import csv
import json

ROOT=Path(__file__).resolve().parent.parent
RESULTS=ROOT/'results'/'tcpflow'
ANALYSIS=ROOT/'analysis'


def brief(path):
    with path.open('rb') as f: data=f.read(180)
    if data.startswith(b'GET '): return 'HTTP GET'
    if data.startswith(b'POST '): return 'HTTP POST'
    if data.startswith(b'HTTP/1.1 '): return 'HTTP response'
    if b'\r\n\r\n' in data: return 'HTTP separator found but invalid start'
    if len(data)==0: return 'EMPTY'
    return f'other prefix={data[:24]!r}'


print('Project:',ROOT)
for s in (f'T{i:02d}' for i in range(6)):
    base=RESULTS/s
    print(f'\n=== {s} ===')
    raw=base/'raw'
    if not raw.is_dir():
        print('ERROR: raw/ NOT FOUND. Look for manual_raw/ or run_tcpflow.py.'); continue
    files=sorted(p for p in raw.rglob('*') if p.is_file())
    nonreport=[p for p in files if p.name not in ('report.xml',) and not p.name.endswith('.findx')]
    print('raw files:',len(files),'; possible reconstructed streams:',len(nonreport))
    for p in files[:22]:
        if p.name=='report.xml': kind='metadata report'
        else: kind=brief(p)
        print(f'  {p.relative_to(raw)} | {p.stat().st_size} bytes | {kind}')
    if len(files)>22: print('  ... more files omitted')
    for mode in ('raw','http'):
        log=base/f'{mode}_execution.log'
        if log.exists():
            content=log.read_text(errors='replace')
            code=next((x for x in content.splitlines() if x.startswith('RETURN_CODE=')), '(no return code)')
            print(f'{mode} execution: {code}')
            if code!='RETURN_CODE=0':print('  Check',log)
        elif mode=='raw':print('WARNING: missing',log)
    metadata=base/'run_metadata.json'
    if metadata.exists():
        try:
            info=json.loads(metadata.read_text())
            for task in info.get('runs',[]):
                print('run metadata:',task.get('mode'), 'return_code=',task.get('return_code'), 'output_files=',len(task.get('files',[])))
        except (OSError,ValueError) as e:print('bad run_metadata:',e)
    if not nonreport:
        print('DIAGNOSIS: no stream files. Investigate tcpflow runner/output; verification cannot extract objects.')
    else:
        print('NOTE: if HTTP files above exist and objects/ is empty, inspect flow discovery and CSV errors.')

csvfile=ANALYSIS/'tcpflow_object_results.csv'
if csvfile.exists():
    print('\n=== Extractor CSV diagnostics ===')
    with csvfile.open(newline='',encoding='utf8') as f:
        for row in csv.DictReader(f):
            if row.get('problem'):
                print(row.get('scenario'),row.get('object_id'), 'flow_found=',row.get('flow_found'), ':',row['problem'])
else:
    print('\nNo tcpflow_object_results.csv. verify_tcpflow.py may not have completed.')
