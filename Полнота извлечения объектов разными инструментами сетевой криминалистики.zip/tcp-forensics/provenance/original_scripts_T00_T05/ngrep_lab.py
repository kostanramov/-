#!/usr/bin/env python3
"""Shared, dependency-free test definitions and PCAP reader for ngrep lab T00-T05.

This parser is deliberately limited to classic PCAP / Ethernet / IPv4 / TCP.
It is NOT a TCP reassembler. It inspects each packet independently.
"""
from __future__ import annotations
import base64
from collections import Counter
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import struct

BASE = Path(__file__).resolve().parent.parent
PCAPS = BASE / 'pcaps'
REFERENCE = BASE / 'reference'
OUT = BASE / 'results' / 'ngrep'
ANALYSIS = BASE / 'analysis'
SCENARIOS = [f'T{i:02d}' for i in range(6)]


@dataclass(frozen=True)
class Test:
    key: str
    object_id: str
    port: int
    direction: str
    full: bytes
    left: bytes
    right: bytes


def get_tests() -> list[Test]:
    credentials = json.loads((REFERENCE / 'credentials.json').read_text(encoding='utf8'))
    post = ('password=' + credentials['form']['password']).encode('ascii')
    basic_token = base64.b64encode(
        (credentials['basic']['username'] + ':' + credentials['basic']['password']).encode('ascii'))
    basic = b'Authorization: Basic ' + basic_token
    tests = [
        Test('small', 'small.txt', 41001, 'response', b'FILE_START_MARKER_SMALL', b'FILE_STA', b'RT_MARKER_SMALL'),
        Test('large', 'large.bin', 41002, 'response', b'FILE_START_MARKER_LARGE', b'FILE_STA', b'RT_MARKER_LARGE'),
        Test('post', 'form_credentials', 41003, 'request', post, post[:4], post[4:]),
        Test('basic', 'basic_credentials', 41004, 'request', basic, basic[:28], basic[28:]),
    ]
    names = dict(small='response_small.http', large='response_large.http',
                 post='post_credentials.http', basic='get_basic.http')
    for case in tests:
        source = (REFERENCE / 'http' / names[case.key]).read_bytes()
        if source.count(case.full) != 1:
            raise ValueError(f'Ground truth does not contain exactly one {case.key} full pattern')
        if case.left + case.right != case.full:
            raise ValueError(f'Fragments incorrect for {case.key}')
    return tests


def parse_scenarios(text: str) -> list[str]:
    names = [x.strip().upper() for x in text.split(',') if x.strip()]
    if not names or len(set(names)) != len(names) or any(x not in SCENARIOS for x in names):
        raise ValueError('Choose a unique comma-separated subset of T00,T01,T02,T03,T04,T05')
    return names


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def metadata(scenario: str) -> dict:
    info = json.loads((PCAPS / f'{scenario}.json').read_text(encoding='utf8'))
    pcappath = PCAPS / f'{scenario}.pcap'
    if info.get('scenario') != scenario or sha256(pcappath) != info.get('pcap_sha256'):
        raise ValueError(f'{scenario}: PCAP hash or metadata mismatch. DO NOT re-create/overwrite experiment PCAP.')
    manifest = REFERENCE / 'manifest.json'
    if sha256(manifest) != info.get('reference_manifest_sha256'):
        raise ValueError(f'{scenario}: reference manifest checksum mismatch')
    return info


@dataclass(frozen=True)
class Packet:
    raw: bytes
    src: str
    dst: str
    sport: int
    dport: int
    payload: bytes


def iter_pcap(path: Path):
    """Yield (linktype, raw frame) from classic PCAP (not PCAPNG)."""
    with path.open('rb') as f:
        global_hdr = f.read(24)
        if len(global_hdr) != 24:
            raise ValueError(f'{path}: too short for PCAP')
        magic = global_hdr[:4]
        if magic in (b'\xd4\xc3\xb2\xa1', b'\x4d\x3c\xb2\xa1'):
            endian = '<'
        elif magic in (b'\xa1\xb2\xc3\xd4', b'\xa1\xb2\x3c\x4d'):
            endian = '>'
        else:
            raise ValueError(f'{path}: unsupported format: expected classic PCAP, not PCAPNG')
        linktype = struct.unpack_from(endian + 'I', global_hdr, 20)[0]
        if linktype != 1:
            raise ValueError(f'{path}: expected Ethernet PCAP (linktype=1), got {linktype}')
        while True:
            hdr = f.read(16)
            if hdr == b'':
                break
            if len(hdr) != 16:
                raise ValueError(f'{path}: truncated PCAP record header')
            _, _, caplen, wirelen = struct.unpack(endian + 'IIII', hdr)
            if caplen > 32*1024*1024 or caplen > wirelen:
                raise ValueError(f'{path}: invalid PCAP frame length')
            raw = f.read(caplen)
            if len(raw) != caplen:
                raise ValueError(f'{path}: truncated PCAP frame')
            yield raw


def decode_tcp(raw: bytes) -> Packet | None:
    """Parse one Ethernet/IPv4/TCP packet without reassembling any data."""
    import ipaddress
    if len(raw) < 14:
        return None
    pos = 12
    ethertype = int.from_bytes(raw[pos:pos+2], 'big')
    pos = 14
    for _ in range(2):
        if ethertype not in (0x8100, 0x88a8):
            break
        if len(raw) < pos+4:
            return None
        ethertype = int.from_bytes(raw[pos+2:pos+4], 'big')
        pos += 4
    if ethertype != 0x0800 or len(raw) < pos+20:
        return None
    ip = raw[pos:]
    if ip[0] >> 4 != 4 or ip[0] & 15 < 5:
        return None
    ihl = (ip[0] & 15) * 4
    if len(ip) < ihl or ip[9] != 6:
        return None
    total = int.from_bytes(ip[2:4], 'big')
    flags_frag = int.from_bytes(ip[6:8], 'big')
    if flags_frag & 0x3FFF:
        # IPv4 fragments are T06, intentionally excluded from this lab.
        return None
    if total < ihl+20 or len(ip) < total:
        return None
    tcp = ip[ihl:total]
    offset = (tcp[12] >> 4) * 4
    if offset < 20 or len(tcp) < offset:
        return None
    return Packet(raw, str(ipaddress.IPv4Address(ip[12:16])),
                  str(ipaddress.IPv4Address(ip[16:20])),
                  int.from_bytes(tcp[0:2], 'big'), int.from_bytes(tcp[2:4], 'big'), tcp[offset:])


def packets(path: Path) -> list[Packet]:
    result = []
    for raw in iter_pcap(path):
        p = decode_tcp(raw)
        if p:
            result.append(p)
    return result


def selected(p: Packet, test: Test, meta: dict) -> bool:
    sender, analyzer = meta['sender_ip'], meta['analyzer_ip']
    if test.direction == 'request':
        return (p.src, p.dst, p.sport, p.dport) == (sender, analyzer, test.port, 8080)
    return (p.src, p.dst, p.sport, p.dport) == (analyzer, sender, 8080, test.port)


def bpf(test: Test) -> str:
    # IP addresses deliberately not hard-coded: ports and directions identify the four fixture streams.
    if test.direction == 'request':
        return f'tcp src port {test.port} and tcp dst port 8080'
    return f'tcp src port 8080 and tcp dst port {test.port}'


def require_no_false_matches(source: list[Packet], matched: list[Packet], test: Test, meta: dict, pattern: bytes):
    expected = Counter(p.raw for p in source if selected(p, test, meta) and pattern in p.payload)
    actual = Counter(p.raw for p in matched)
    if actual != expected:
        raise AssertionError(f'{test.key} {pattern!r}: ngrep matched PCAP packets differ from expected exact per-packet substring matches: expected {sum(expected.values())}, got {sum(actual.values())}')
    return sum(expected.values())
