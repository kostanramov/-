#!/usr/bin/env python3
"""Create reproducible synthetic Ethernet/IPv4/TCP PCAP fixtures from step-2 references.

No packets are sent to a live interface. All test credentials are synthetic.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from scapy.all import Ether, IP, TCP, Raw, fragment, wrpcap

BASE = Path(__file__).resolve().parent.parent
REF = BASE / "reference"
OUT = BASE / "pcaps"
SENDER = "192.168.56.10"
ANALYZER = "192.168.56.20"
SENDER_MAC = "08:00:27:8D:3A:49"
ANALYZER_MAC = "08:00:27:CA:80:84"
PORT = 8080
START_TIME = 1760918400.0   # fixed epoch for reproducibility; NOT wall time

FLOWS = [
    ("small", 41001, "get_small.http", "response_small.http"),
    ("large", 41002, "get_large.http", "response_large.http"),
    ("post", 41003, "post_credentials.http", "response_post.http"),
    ("basic", 41004, "get_basic.http", "response_basic.http"),
]
SCENARIOS = {
    "T00": "Baseline: four HTTP transactions; ordinary TCP segmentation",
    "T01": "Small 512-byte TCP segments for large response",
    "T02": "Full search markers deliberately split across TCP segments",
    "T03": "Out-of-order large-response TCP data segments (0,2,1,3,...)",
    "T04": "Duplicate TCP segment in large response and POST request",
    "T05": "One large-response data segment missing from the *capture*",
    "T06": "OPTIONAL: IPv4 fragmentation of one large-response TCP datagram",
}


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def split_payload(data: bytes, chunk: int, forced_cuts: tuple[int, ...] = ()) -> list[tuple[int, bytes]]:
    """Return (offset,payload), forcing specified boundaries exactly."""
    assert chunk > 0
    boundaries = sorted(set(forced_cuts))
    assert all(0 < cut < len(data) for cut in boundaries), boundaries
    result = []
    offset = 0
    while offset < len(data):
        stop = min(offset + chunk, len(data))
        for cut in boundaries:
            if offset < cut < stop:
                stop = cut
                break
        assert stop > offset
        result.append((offset, data[offset:stop]))
        offset = stop
    assert b"".join(payload for _, payload in result) == data
    return result


def location_of_cut(data: bytes, pattern: bytes, after: int) -> int:
    assert data.count(pattern) == 1, f"Pattern must occur once: {pattern!r}"
    assert 0 < after < len(pattern)
    return data.index(pattern) + after


class Capture:
    def __init__(self, name: str):
        self.name = name
        self.packets = []
        self.ip_id = 100
        self.events = []
        self.removed = []
        self.timestamps = START_TIME

    def emit(self, src: str, dst: str, sport: int, dport: int,
             seq: int, ack: int, flags: str, data: bytes = b"", *,
             options=None, remove: bool = False, ipfrag: bool = False,
             note: str = ""):
        src_mac = SENDER_MAC if src == SENDER else ANALYZER_MAC
        dst_mac = SENDER_MAC if dst == SENDER else ANALYZER_MAC
        header = Ether(src=src_mac, dst=dst_mac) / IP(
            src=src, dst=dst, ttl=64, id=self.ip_id,
            flags="DF" if not ipfrag else 0,
        ) / TCP(
            sport=sport, dport=dport, seq=seq, ack=ack,
            flags=flags, window=65535, options=options or [],
        )
        self.ip_id += 1
        if data:
            header = header / Raw(load=data)
        if ipfrag:
            assert data and not remove
            # IPv4 fragment payload sizes must be multiples of 8 except last.
            packets = [Ether(src=src_mac, dst=dst_mac) / f
                       for f in fragment(header[IP], fragsize=400)]
            assert len(packets) > 1
        else:
            packets = [header]
        for packet in packets:
            packet.time = self.timestamps
            self.timestamps += 0.001
            if not remove:
                self.packets.append(packet)
        event = {
            "src": src, "dst": dst, "sport": sport, "dport": dport,
            "seq": seq, "data_bytes": len(data), "flags": flags,
            "note": note,
        }
        if remove:
            self.removed.append(event)
        elif data or ipfrag:
            self.events.append(event)


def deliver(capture: Capture, src: str, sport: int, dst: str, dport: int,
            stream: bytes, sender_seq: int, receiver_seq: int,
            *, chunk_size: int, forced_cuts: tuple[int, ...] = (),
            reorder: bool = False, duplicate_at: int | None = None,
            removed_at: int | None = None, fragment_at: int | None = None,
            label: str = "") -> int:
    """Send a byte stream with cumulative ACKs; ACK state reflects wire, not PCAP loss."""
    pieces = split_payload(stream, chunk_size, forced_cuts)
    if reorder:
        assert len(pieces) >= 3
        order = [0, 2, 1] + list(range(3, len(pieces)))
    else:
        order = list(range(len(pieces)))
    covered = set()
    receiver_offset = 0
    for idx in order:
        offset, payload = pieces[idx]
        # Missing from capture does not imply it was dropped on the wire.
        capture.emit(src, dst, sport, dport, sender_seq + offset, receiver_seq,
                     "PA", payload, remove=(idx == removed_at),
                     ipfrag=(idx == fragment_at), note=f"{label} #{idx}")
        if idx == duplicate_at:
            capture.emit(src, dst, sport, dport, sender_seq + offset, receiver_seq,
                         "PA", payload, note=f"{label} #{idx} RETRANSMISSION")
        covered.add(idx)
        while receiver_offset < len(stream):
            next_idx = next((j for j, (start, _) in enumerate(pieces)
                            if start == receiver_offset), None)
            if next_idx is None or next_idx not in covered:
                break
            receiver_offset += len(pieces[next_idx][1])
        # Reverse-direction cumulative ACK. May repeat when data arrive out of order.
        capture.emit(dst, src, dport, sport, receiver_seq,
                     sender_seq + receiver_offset, "A")
    assert receiver_offset == len(stream)
    return sender_seq + len(stream)


def build_capture(name: str, messages: dict[str, bytes]) -> Capture:
    c = Capture(name)
    for index, (flow, sport, request_file, response_file) in enumerate(FLOWS):
        request = messages[request_file]
        response = messages[response_file]
        client_isn = 1_000_000 + 100_000 * index
        server_isn = 2_000_000 + 100_000 * index
        c.emit(SENDER, ANALYZER, sport, PORT, client_isn, 0, "S",
               options=[("MSS", 1460), ("WScale", 7)])
        c.emit(ANALYZER, SENDER, PORT, sport, server_isn,
               client_isn + 1, "SA", options=[("MSS", 1460), ("WScale", 7)])
        c.emit(SENDER, ANALYZER, sport, PORT, client_isn + 1,
               server_isn + 1, "A")
        req_cuts = ()
        resp_cuts = ()
        req_chunk_size = 1460
        resp_chunk_size = 1460
        if name == "T01" and flow == "large":
            resp_chunk_size = 512
        if name == "T02":
            if flow == "post":
                req_cuts = (location_of_cut(request, b"password=TEST_SECRET_2026", 4),)
            if flow == "basic":
                req_cuts = (location_of_cut(request, b"Authorization: Basic bGFidXNlcj", 28),)
            if flow == "small":
                resp_cuts = (location_of_cut(response, b"FILE_START_MARKER_SMALL", 8),)
            if flow == "large":
                resp_cuts = (location_of_cut(response, b"FILE_START_MARKER_LARGE", 8),)
        # The full request is delivered before the response. One HTTP object per connection.
        client_next = deliver(
            c, SENDER, sport, ANALYZER, PORT, request,
            client_isn + 1, server_isn + 1,
            chunk_size=req_chunk_size, forced_cuts=req_cuts,
            duplicate_at=0 if name == "T04" and flow == "post" else None,
            label=f"{flow} request",
        )
        server_next = deliver(
            c, ANALYZER, PORT, SENDER, sport, response,
            server_isn + 1, client_next,
            chunk_size=resp_chunk_size, forced_cuts=resp_cuts,
            reorder=name == "T03" and flow == "large",
            duplicate_at=4 if name == "T04" and flow == "large" else None,
            removed_at=8 if name == "T05" and flow == "large" else None,
            fragment_at=0 if name == "T06" and flow == "large" else None,
            label=f"{flow} response",
        )
        # Bidirectional FIN handshake (FIN consumes one sequence number).
        c.emit(SENDER, ANALYZER, sport, PORT, client_next, server_next, "FA")
        c.emit(ANALYZER, SENDER, PORT, sport, server_next, client_next + 1, "A")
        c.emit(ANALYZER, SENDER, PORT, sport, server_next, client_next + 1, "FA")
        c.emit(SENDER, ANALYZER, sport, PORT, client_next + 1, server_next + 1, "A")
    return c


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--include-ipfrag", action="store_true",
                        help="Also generate optional T06 (separate IP fragmentation experiment)")
    parser.add_argument("--only", choices=list(SCENARIOS), default=None,
                        help="Generate only one scenario, for example --only T06")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing generated PCAPs/metadata")
    args = parser.parse_args()

    manifest = json.loads((REF / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["dataset_version"] == "tcp-forensics-v1"
    for item in manifest["artifacts"]:
        path = REF / item["path"]
        assert len(path.read_bytes()) == item["bytes"], item["path"]
        assert file_hash(path) == item["sha256"], item["path"]
    messages = {name: (REF / "http" / name).read_bytes()
                for _, _, req, resp in FLOWS for name in (req, resp)}
    assert (REF / "small.txt").read_bytes() in messages["response_small.http"]
    assert (REF / "large.bin").read_bytes() in messages["response_large.http"]
    scenarios = ([args.only] if args.only else
                 (list(SCENARIOS) if args.include_ipfrag else list(SCENARIOS)[:-1]))
    OUT.mkdir(parents=True, exist_ok=True)
    for scenario in scenarios:
        pcap_path = OUT / f"{scenario}.pcap"
        info_path = OUT / f"{scenario}.json"
        if not args.force and (pcap_path.exists() or info_path.exists()):
            raise SystemExit(f"Refusing to overwrite {pcap_path}; use --force deliberately")
        capture = build_capture(scenario, messages)
        wrpcap(str(pcap_path), capture.packets)
        metadata = {
            "scenario": scenario,
            "description": SCENARIOS[scenario],
            "synthetic_offline_capture": True,
            "sender_ip": SENDER,
            "analyzer_ip": ANALYZER,
            "reference_manifest_sha256": file_hash(REF / "manifest.json"),
            "packets": len(capture.packets),
            "pcap_sha256": file_hash(pcap_path),
            "flows": [{"name": n, "src_port": p, "http_request": q, "http_response": r}
                      for n, p, q, r in FLOWS],
            "deliberately_omitted_from_capture": capture.removed,
        }
        info_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"{scenario}: {len(capture.packets)} packets, {pcap_path.stat().st_size} bytes, sha256={metadata['pcap_sha256']}")
    print("PASS: all selected synthetic PCAPs generated without changing reference data")


if __name__ == "__main__":
    main()
