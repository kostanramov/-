#!/usr/bin/env python3
"""V2: Inspect tcpflow's *raw* reconstructed streams against canonical references.

One CSV row per scenario and tested object. Also compares the eight raw HTTP
streams verbatim to the eight canonical HTTP messages. The optional tcpflow
HTTPBODY scanner output is a separate secondary evaluation, never substituted
for the primary raw TCP stream bytes.
"""
from __future__ import annotations
import argparse
import base64
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.parse import parse_qs

ROOT = Path(__file__).resolve().parent.parent
REF = ROOT / 'reference'
RESULTS = ROOT / 'results' / 'tcpflow'
ANALYSIS = ROOT / 'analysis'
SENDER = '192.168.56.10'
ANALYZER = '192.168.56.20'
SERVER_PORT = 8080
FLOWS = {
    'small': {'port': 41001, 'request': 'get_small.http', 'response': 'response_small.http', 'object': 'small.txt'},
    'large': {'port': 41002, 'request': 'get_large.http', 'response': 'response_large.http', 'object': 'large.bin'},
    'post':  {'port': 41003, 'request': 'post_credentials.http', 'response': 'response_post.http', 'object': 'form_credentials'},
    'basic': {'port': 41004, 'request': 'get_basic.http', 'response': 'response_basic.http', 'object': 'basic_credentials'},
}
# tcpflow default format: padded or unpadded IPv4 and port on both sides.
PAIR_RE = re.compile(r'(?P<src>\d{1,3}(?:\.\d{1,3}){3})\.(?P<srcport>\d{1,5})-'
                     r'(?P<dst>\d{1,3}(?:\.\d{1,3}){3})\.(?P<dstport>\d{1,5})')
FIELDS = ['scenario', 'object_id', 'object_type', 'flow_file', 'flow_found',
          'raw_stream_sha256_exact', 'http_parse_ok', 'http_body_complete',
          'expected_size', 'recovered_size', 'expected_sha256', 'recovered_sha256',
          'object_exact', 'credential_exact', 'postprocessor_httpbody_found',
          'postprocessor_httpbody_exact', 'problem']
FLOW_FIELDS = ['scenario', 'name', 'direction', 'found', 'stream_file', 'recovered_length',
               'expected_length', 'expected_sha256', 'recovered_sha256', 'raw_stream_sha256_exact', 'problem']


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def ip(s: str) -> str:
    return '.'.join(str(int(octet)) for octet in s.split('.'))


def parse_flow_name(path: Path):
    name = path.name
    if name.endswith(('-HTTP', '-HTTPBODY', '-HTTPBODY-GZIP', '.findx')) or 'report' in name.lower():
        return None
    match = PAIR_RE.search(name)
    if not match:
        return None
    try:
        return (ip(match['src']), int(match['srcport']), ip(match['dst']), int(match['dstport']))
    except (ValueError, IndexError):
        return None


def index_raw_flows(folder: Path):
    """Index actual tcpflow flow files; do not invent or reconstruct any TCP bytes.

    Primary mapping: src/dst IP+port in tcpflow's filename. Fallback for
    version/custom naming: unique lab client port + HTTP start-line direction.
    The fallback only *classifies* real output files; their bytes are unchanged.
    """
    streams = {}
    if not folder.is_dir():
        return streams, []
    not_classified = []
    for path in sorted(folder.rglob('*')):
        if not path.is_file():
            continue
        if path.name == 'report.xml' or path.name.endswith(('.findx','-HTTP','-HTTPBODY','-HTTPBODY-GZIP')):
            continue
        key = parse_flow_name(path)
        method = 'filename_endpoint'
        if key is None:
            # Alternate output naming seen with customized -T templates.
            # Only accept a UNIQUE client port, and use the actual HTTP start line.
            ports = {int(p) for p in re.findall(r'(?<!\d)(4100[1-4])(?!\d)', path.name)}
            head = path.open('rb').read(128)
            if len(ports) == 1:
                port = next(iter(ports))
                if head.startswith((b'GET ', b'POST ')):
                    key = (SENDER, port, ANALYZER, SERVER_PORT)
                    method = 'port_and_http_request'
                elif head.startswith(b'HTTP/1.'):
                    key = (ANALYZER, SERVER_PORT, SENDER, port)
                    method = 'port_and_http_response'
            # For requests only, path-independent fallback using unique HTTP targets.
            if key is None:
                for name, spec in FLOWS.items():
                    prefix = {
                        'small':b'GET /small.txt ', 'large':b'GET /large.bin ',
                        'post':b'POST /login ', 'basic':b'GET /auth-check '
                    }[name]
                    if head.startswith(prefix):
                        key = (SENDER, spec['port'], ANALYZER, SERVER_PORT)
                        method = 'http_request_path'
                        break
        if key is None:
            not_classified.append((path, 'unrecognised filename and HTTP signature'))
        else:
            streams.setdefault(key, []).append((path,method))
    return streams, not_classified


def extract_http(message: bytes):
    """Minimal RFC-compatible parser for the fixed test fixture (one HTTP/1.1 message per stream).

    Deliberately no chunked/gzip/HTTP pipelining; rejects ambiguous/extra bytes.
    """
    head, separator, body = message.partition(b'\r\n\r\n')
    if not separator:
        raise ValueError('HTTP header separator CRLFCRLF missing')
    header_lines = head.split(b'\r\n')
    if not header_lines[0].startswith((b'HTTP/1.1 ', b'GET ', b'POST ')):
        raise ValueError('HTTP start line incorrect')
    headers = {}
    for line in header_lines[1:]:
        if b':' not in line:
            raise ValueError('malformed HTTP header')
        name, value = line.split(b':', 1)
        key = name.strip().lower()
        headers.setdefault(key, []).append(value.strip())
    if b'content-length' in headers:
        values = headers[b'content-length']
        if len(values) != 1 or not values[0].isdigit():
            raise ValueError('Content-Length invalid or ambiguous')
        length = int(values[0])
        if length != len(body):
            raise ValueError(f'Content-Length={length}, but received body={len(body)} bytes')
    elif body:
        raise ValueError('unexpected body without Content-Length')
    return header_lines[0], headers, body


def check_credentials(kind: str, headers, body: bytes, expected):
    if kind == 'post':
        values = parse_qs(body.decode('ascii'), keep_blank_values=True, strict_parsing=True)
        return values == {'username':[expected['username']], 'password':[expected['password']]}
    if kind == 'basic':
        auth = headers.get(b'authorization', [])
        if len(auth) != 1 or not auth[0].startswith(b'Basic '):
            return False
        original = base64.b64decode(auth[0][6:], validate=True).decode('ascii')
        return original == f"{expected['username']}:{expected['password']}"
    raise ValueError(f'unexpected credential kind: {kind}')


def find_httpbody_files(folder: Path, flowname: str) -> list[Path]:
    if not folder.is_dir():
        return []
    return [f for f in folder.rglob('*') if f.is_file() and
            f.name.endswith('-HTTPBODY') and parse_postprocessed_endpoint(f) == flowname]


def parse_postprocessed_endpoint(path: Path) -> str | None:
    # Compare prefix from name; tcpflow adds -HTTPBODY to raw flow filename.
    return path.name[:-len('-HTTPBODY')] if path.name.endswith('-HTTPBODY') else None


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]):
    with path.open('w', newline='', encoding='utf8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--scenarios', default='T00,T01,T02,T03,T04,T05')
    cli.add_argument('--debug', action='store_true', help='Print flow discovery and non-classified files')
    cli.add_argument('--raw-subdir', default='raw', help='Use alternate tcpflow output subfolder, e.g. debug_run')
    args = cli.parse_args()
    if '/' in args.raw_subdir or args.raw_subdir in ('', '.', '..'):
        cli.error('--raw-subdir must be a simple folder name')
    scenarios = [x.strip().upper() for x in args.scenarios.split(',') if x.strip()]
    if not scenarios or any(x not in [f'T{i:02d}' for i in range(7)] for x in scenarios):
        cli.error('Use scenario list T00...T06')
    creds = json.loads((REF/'credentials.json').read_text(encoding='utf8'))
    manifest = json.loads((REF/'manifest.json').read_text(encoding='utf8'))
    known_hash = {a['path']: a['sha256'] for a in manifest['artifacts']}
    for name in ['small.txt','large.bin']:
        if sha((REF/name).read_bytes()) != known_hash[name]:
            raise SystemExit(f'ERROR: reference hash changed: {name}')

    object_rows = []
    flow_rows = []
    for scenario in scenarios:
        raw_folder = RESULTS/scenario/args.raw_subdir
        if not raw_folder.is_dir():
            print(f'WARNING {scenario}: {raw_folder} missing; all streams will be marked missing', file=sys.stderr)
        files, unclassified = index_raw_flows(raw_folder)
        for p, why in unclassified:
            print(f'WARNING {scenario}: unclassified {p.name}: {why}', file=sys.stderr)
        if args.debug:
            for key, matches in sorted(files.items()):
                print(f'DISCOVERED {scenario} {key}: ' +
                      ', '.join(f'{p.name} ({method})' for p,method in matches))
        expected_keys = {
            key for spec in FLOWS.values() for key in (
                (SENDER,spec['port'],ANALYZER,SERVER_PORT),
                (ANALYZER,SERVER_PORT,SENDER,spec['port'])
            )
        }
        if not set(files).intersection(expected_keys):
            candidates = [p.name for p in sorted(raw_folder.rglob('*')) if p.is_file()] if raw_folder.is_dir() else []
            preview = ', '.join(candidates[:15]) or '(none)'
            logpath = RESULTS/scenario/'raw_execution.log'
            raise SystemExit(
                f'ERROR {scenario}: not a single expected raw TCP flow was recognized!\n'
                f'Found in raw/: {preview}\n'
                f'Check {logpath} (RETURN_CODE and STDERR).\n'
                'If the directory contains only report.xml, tcpflow did not create flow files.\n'
                'If flow files exist, inspect filenames and run with --debug.\n'
                'No empty objects/ directory has been created for this scenario.'
            )
        dest = RESULTS/scenario/'objects'
        dest.mkdir(exist_ok=True, parents=True)
        for name, spec in FLOWS.items():
            p = spec['port']
            request_key = (SENDER, p, ANALYZER, SERVER_PORT)
            response_key = (ANALYZER, SERVER_PORT, SENDER, p)
            recovered = {}
            for direction, key, httpname in [('request', request_key, spec['request']),
                                            ('response', response_key, spec['response'])]:
                expected_bytes = (REF/'http'/httpname).read_bytes()
                matching = files.get(key, [])
                problems = ''
                if len(matching) == 1:
                    path, recognition_method = matching[0]
                    actual_bytes = path.read_bytes()
                    ok = actual_bytes == expected_bytes
                    recovered[direction] = (actual_bytes, path)
                else:
                    path = None
                    actual_bytes = b''
                    ok = False
                    problems = 'No matching raw flow file' if not matching else 'Multiple flow files for one direction: ' + ', '.join(p.name for p,_ in matching)
                    recovered[direction] = (None, None)
                flow_rows.append({
                    'scenario':scenario, 'name':name, 'direction':direction,
                    'found':len(matching) == 1,
                    'stream_file':str(path.relative_to(ROOT)) if path else '',
                    'recovered_length':len(actual_bytes) if path else '',
                    'expected_length':len(expected_bytes),
                    'expected_sha256':sha(expected_bytes),
                    'recovered_sha256':sha(actual_bytes) if path else '',
                    'raw_stream_sha256_exact':ok,
                    'problem':problems,
                })
            main_direction = 'request' if name in ('post','basic') else 'response'
            raw_bytes, stream_path = recovered[main_direction]
            expected_object = (REF/spec['object']).read_bytes() if name in ('small','large') else (REF/'http'/spec['request']).read_bytes()
            report = {
                'scenario':scenario, 'object_id':spec['object'],
                'object_type':'file' if name in ('small','large') else 'credentials',
                'flow_file':str(stream_path.relative_to(ROOT)) if stream_path else '',
                'flow_found':stream_path is not None,
                'raw_stream_sha256_exact':flow_rows[-1 if main_direction == 'response' else -2]['raw_stream_sha256_exact'],
                'http_parse_ok':False, 'http_body_complete':False,
                'expected_size':len(expected_object) if name in ('small','large') else '',
                'recovered_size':'',
                'expected_sha256':known_hash.get(spec['object']) if name in ('small','large') else '',
                'recovered_sha256':'', 'object_exact':False, 'credential_exact':'',
                'postprocessor_httpbody_found':'', 'postprocessor_httpbody_exact':'',
                'problem':'',
            }
            if stream_path is None:
                report['problem'] = f'{main_direction} flow not found'
                object_rows.append(report)
                continue
            if name in ('small', 'large'):
                # Evaluate the built-in HTTP postprocessor independently from our parser.
                scanner_files = find_httpbody_files(RESULTS/scenario/'http', stream_path.name)
                report['postprocessor_httpbody_found'] = len(scanner_files) == 1
                if len(scanner_files) == 1:
                    report['postprocessor_httpbody_exact'] = (
                        scanner_files[0].read_bytes() == (REF/spec['object']).read_bytes()
                    )
                elif len(scanner_files) > 1:
                    report['problem'] = 'Several -HTTPBODY postprocessor files for one flow'
            try:
                start, headers, body = extract_http(raw_bytes)
                report['http_parse_ok'] = True
                report['http_body_complete'] = True
                if name in ('small','large'):
                    actual = body
                    ground = (REF/spec['object']).read_bytes()
                    report['expected_sha256'] = sha(ground)
                    report['recovered_size'] = len(actual)
                    report['recovered_sha256'] = sha(actual)
                    report['object_exact'] = (actual == ground)
                    (dest/spec['object']).write_bytes(actual)
                    if not report['object_exact']:
                        report['problem'] = 'Object recovered but content differs from ground truth'
                else:
                    which = 'post' if name=='post' else 'basic'
                    ok = check_credentials(which, headers, body, creds['form'] if which=='post' else creds['basic'])
                    report['object_exact'] = ok
                    report['credential_exact'] = ok
                    if not ok:
                        report['problem'] = 'Decoded credentials do not match reference'
                    # Write verification status, not plaintext secrets, to object report.
                    (dest/(which+'_verification.json')).write_text(
                        json.dumps({'scenario':scenario, 'kind':which, 'credential_exact':ok}, indent=2)+'\n', encoding='utf8'
                    )
            except (ValueError, UnicodeError, KeyError, TypeError, base64.binascii.Error) as exc:
                report['problem'] = f'HTTP parse/extraction failed: {exc}'
                if b'\r\n\r\n' in raw_bytes:
                    # Record available body size even if declared Content-Length fails.
                    report['recovered_size'] = len(raw_bytes.partition(b'\r\n\r\n')[2])
                    fragment = raw_bytes.partition(b'\r\n\r\n')[2]
                    report['recovered_sha256'] = sha(fragment)
                    if name in ('small', 'large'):
                        # Explicitly mark as unverified; do not create the canonical filename.
                        (dest/(spec['object']+'.unverified')).write_bytes(fragment)
            object_rows.append(report)
        count_ok = sum(bool(r['object_exact']) for r in object_rows if r['scenario']==scenario)
        print(f'{scenario}: recognized={len(files)} endpoint(s); objects exactly recovered {count_ok}/4')

    ANALYSIS.mkdir(parents=True, exist_ok=True)
    write_csv(ANALYSIS/'tcpflow_object_results.csv', object_rows, FIELDS)
    write_csv(ANALYSIS/'tcpflow_flow_results.csv', flow_rows, FLOW_FIELDS)
    summary = {'scenarios':scenarios, 'objects':len(object_rows), 'exact_objects':sum(bool(r['object_exact']) for r in object_rows),
               'objects_by_scenario':{s:sum(bool(r['object_exact']) for r in object_rows if r['scenario']==s) for s in scenarios},
               'note':'Measured by byte comparison of extracted HTTP body or decoded test credentials; HTTPBODY scanner is secondary.'}
    (ANALYSIS/'tcpflow_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    print('Saved:', ANALYSIS/'tcpflow_object_results.csv')
    print('Saved:', ANALYSIS/'tcpflow_flow_results.csv')
    print('Saved:', ANALYSIS/'tcpflow_summary.json')


if __name__ == '__main__':
    main()
