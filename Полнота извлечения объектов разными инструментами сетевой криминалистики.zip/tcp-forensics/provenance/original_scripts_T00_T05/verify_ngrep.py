#!/usr/bin/env python3
"""Stage 5 verification: count ngrep matched PACKETS from -O PCAP files.

This script is an independent per-packet audit, NOT an extraction or a TCP
stream reassembly. It compares ngrep's saved matching frames to exact
payload substring matches in the original immutable PCAP.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import sys

from ngrep_lab import (ANALYSIS, BASE, OUT, PCAPS, SCENARIOS, get_tests,
                       iter_pcap, metadata, packets, parse_scenarios,
                       require_no_false_matches, selected)

FIELDS = [
    'scenario', 'object_id', 'direction', 'client_port', 'pattern',
    'ngrep_exit_code', 'full_pattern_detected', 'full_matched_packets',
    'expected_packet_matches', 'left_fragment_packets', 'right_fragment_packets',
    'all_expected_bytes_in_pcap', 'native_file_reconstruction', 'sha256_comparable',
    'packet_audit_pass', 'note',
]


def inspect_case(folder: Path, label: str, test, meta, original):
    found = folder / f'{label}_matched.pcap'
    stdout = folder / f'{label}.txt'
    stderr = folder / f'{label}.stderr.txt'
    if not stdout.exists() or not stderr.exists():
        raise ValueError(f'Missing output logs for {test.key} {label}; run run_ngrep.py first')
    if found.exists():
        selected_packets = packets(found)
    else:
        selected_packets = []
    p = {'full': test.full, 'left': test.left, 'right': test.right}[label]
    count = require_no_false_matches(original, selected_packets, test, meta, p)
    return count


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scenarios', default=','.join(SCENARIOS))
    cli = parser.parse_args()
    try:
        scenarios = parse_scenarios(cli.scenarios)
        tests = get_tests()
        rows = []
        summary = []
        for scenario in scenarios:
            meta = metadata(scenario)
            original = packets(PCAPS / f'{scenario}.pcap')
            run_file = OUT / scenario / 'run_metadata.json'
            if not run_file.exists():
                raise ValueError(f'Missing {run_file}; run run_ngrep.py first')
            run_meta = json.loads(run_file.read_text(encoding='utf8'))
            if run_meta['pcap_sha256'] != meta['pcap_sha256']:
                raise ValueError(f'{scenario}: ngrep output tied to a different PCAP hash')
            run_lookup = {(r['object_id'], r['test']): r for r in run_meta['runs']}
            detected = 0
            for test in tests:
                case_folder = OUT / scenario / test.key
                record = run_lookup[(test.object_id, 'full')]
                count = inspect_case(case_folder, 'full', test, meta, original)
                full_expected = sum(test.full in pkt.payload for pkt in original if selected(pkt,test,meta))
                if count != full_expected:
                    raise ValueError(f'{scenario}/{test.key}: unexpected ngrep match count')
                if record['exit_code'] != (0 if count else 1):
                    raise ValueError(f'{scenario}/{test.key}: ngrep exit code {record["exit_code"]} incompatible with {count} matches')
                left, right = '', ''
                if scenario == 'T02':
                    left = inspect_case(case_folder, 'left', test, meta, original)
                    right = inspect_case(case_folder, 'right', test, meta, original)
                    for label, n in [('left', left), ('right', right)]:
                        if run_lookup[(test.object_id,label)]['exit_code'] != (0 if n else 1):
                            raise ValueError(f'{scenario}/{test.key}/{label}: exit code inconsistent')
                    if count != 0 or not left or not right:
                        raise ValueError(f'{scenario}/{test.key}: expected split pattern with both fragments present')
                # Independent test from stage 3: stream completeness is a PCAP property,
                # not a result of ngrep. For T05/large only one TCP segment is omitted.
                stream_complete = not (scenario == 'T05' and test.key == 'large')
                detected += int(count > 0)
                rows.append({
                    'scenario': scenario, 'object_id': test.object_id,
                    'direction': test.direction, 'client_port': test.port,
                    'pattern': test.full.decode('ascii'),
                    'ngrep_exit_code': record['exit_code'],
                    'full_pattern_detected': bool(count),
                    'full_matched_packets': count,
                    'expected_packet_matches': full_expected,
                    'left_fragment_packets': left,
                    'right_fragment_packets': right,
                    'all_expected_bytes_in_pcap': stream_complete,
                    'native_file_reconstruction': False,
                    'sha256_comparable': False,
                    'packet_audit_pass': True,
                    'note': ('Complete pattern split across TCP segments' if scenario == 'T02'
                             else 'PCAP missing 1460 bytes of large response' if not stream_complete
                             else 'ngrep matched packets only; no HTTP object exported'),
                })
            summary.append({'scenario': scenario, 'full_patterns_detected': detected,
                            'total_patterns': len(tests),
                            'detection_rate': detected / len(tests),
                            'native_reconstructed_files': 0})
            print(f'{scenario}: full-pattern detection {detected}/4; packet-level audit PASS')
        ANALYSIS.mkdir(exist_ok=True, parents=True)
        out = ANALYSIS / 'ngrep_object_results.csv'
        with out.open('w', newline='', encoding='utf8') as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        (ANALYSIS / 'ngrep_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf8')
        print(f'PASS: wrote {out.relative_to(BASE)} and analysis/ngrep_summary.json')
        return 0
    except (ValueError, AssertionError, KeyError, FileNotFoundError) as exc:
        print('ERROR:', exc, file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
