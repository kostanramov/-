#!/usr/bin/env python3
"""Optional comparison of two DIFFERENT capabilities: ngrep pattern discovery and tcpflow object recovery.

Never equates an ngrep packet match to a byte-accurate reconstructed file.
"""
from __future__ import annotations
import csv
from pathlib import Path
import sys
from ngrep_lab import BASE, ANALYSIS


def csvrows(path: Path):
    if not path.exists():
        raise FileNotFoundError(f'Missing {path}; first finish stage 4/5 verification')
    with path.open(newline='', encoding='utf8') as f:
        return list(csv.DictReader(f))


def main():
    ng = csvrows(ANALYSIS / 'ngrep_object_results.csv')
    tcp = csvrows(ANALYSIS / 'tcpflow_object_results.csv')
    tcp_by_key = {(row['scenario'], row['object_id']): row for row in tcp}
    out=[]
    for entry in ng:
        key=(entry['scenario'],entry['object_id'])
        if key not in tcp_by_key:
            raise ValueError(f'No tcpflow data for {key}. Run tcpflow verification for this scenario.')
        row=tcp_by_key[key]
        if row['object_type']=='file':
            exact=row['object_exact'].strip().lower()=='true'
        else:
            exact=row['credential_exact'].strip().lower()=='true'
        out.append({'scenario':entry['scenario'], 'object_id':entry['object_id'],
                    'ngrep_full_pattern_detected':entry['full_pattern_detected'],
                    'ngrep_matching_packets':entry['full_matched_packets'],
                    'tcpflow_raw_stream_exact':row['raw_stream_sha256_exact'],
                    'tcpflow_object_exact':exact,
                    'ngrep_native_object_export':'not supported in this test setup',
                    'interpretation': ('tcpflow exact; ngrep missed packet-split full marker'
                        if exact and entry['full_pattern_detected']=='False'
                        else 'ngrep marker visible; tcpflow object not exact' if not exact and entry['full_pattern_detected']=='True'
                        else 'ngrep marker visible; tcpflow exact' if exact else 'neither complete marker nor exact tcpflow object')})
    path=ANALYSIS / 'ngrep_tcpflow_comparison.csv'
    with path.open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f, fieldnames=list(out[0]))
        writer.writeheader();writer.writerows(out)
    print(f'Wrote {path.relative_to(BASE)} ({len(out)} rows).')
    print('NOTE: ngrep marker detection != byte-accurate TCP/HTTP file extraction.')


if __name__=='__main__':
    try:
        main()
    except (FileNotFoundError, ValueError) as exc:
        print('ERROR:',exc,file=sys.stderr)
        raise SystemExit(2)
