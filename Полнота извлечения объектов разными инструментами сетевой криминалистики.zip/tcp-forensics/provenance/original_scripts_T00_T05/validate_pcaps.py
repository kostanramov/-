#!/usr/bin/env python3
"""Independent PCAP-to-reference coverage audit via Scapy (NOT tcpflow/ngrep)."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from collections import Counter

from scapy.all import IP, TCP, rdpcap

BASE = Path(__file__).resolve().parent.parent
REF = BASE / "reference"
DIR = BASE / "pcaps"
SENDER = "192.168.56.10"
ANALYZER = "192.168.56.20"
SESSIONS = [
    ("small", 41001, "get_small.http", "response_small.http"),
    ("large", 41002, "get_large.http", "response_large.http"),
    ("post", 41003, "post_credentials.http", "response_post.http"),
    ("basic", 41004, "get_basic.http", "response_basic.http"),
]


def require(test, message):
    if not test:
        raise AssertionError(message)


def audit_stream(packets, *, src, dst, sport, dport, initial_seq, expected):
    content = bytearray(len(expected))
    seen = bytearray(len(expected))
    seen_ranges = Counter()
    observed_order = []
    for packet in packets:
        if IP not in packet or TCP not in packet:
            continue
        ip, tcp = packet[IP], packet[TCP]
        if (ip.src, ip.dst, tcp.sport, tcp.dport) != (src, dst, sport, dport):
            continue
        data = bytes(tcp.payload)
        if not data:
            continue
        offset = (tcp.seq - initial_seq) % (2**32)
        require(offset < len(expected), f"TCP payload outside expected stream: {offset}")
        require(offset + len(data) <= len(expected), "TCP payload exceeds expected stream")
        seen_ranges[(offset, len(data))] += 1
        observed_order.append((offset, len(data)))
        for i, value in enumerate(data):
            index = offset + i
            if seen[index]:
                require(content[index] == value, f"Conflicting repeated TCP data at offset {index}")
            else:
                content[index] = value
                seen[index] = 1
    # Assert all recorded bytes are identical to the reference, even when capture has gaps.
    for i, present in enumerate(seen):
        if present:
            require(content[i] == expected[i], f"Unexpected byte at offset {i}")
    missing = len(expected) - sum(seen)
    redundant = sum(n - 1 for n in seen_ranges.values() if n > 1)
    nonmonotonic = any(observed_order[i][0] < observed_order[i - 1][0]
                       for i in range(1, len(observed_order)))
    return {"missing_bytes": missing,
            "covered_bytes": sum(seen),
            "expected_bytes": len(expected),
            "duplicate_payload_ranges": redundant,
            "nonmonotonic_seq_order": nonmonotonic,
            "segments": len(observed_order)}


def verify_one(scenario: str):
    path = DIR / f"{scenario}.pcap"
    meta = json.loads((DIR / f"{scenario}.json").read_text(encoding="utf-8"))
    require(hashlib.sha256(path.read_bytes()).hexdigest() == meta["pcap_sha256"],
            "PCAP SHA-256 mismatch")
    require(hashlib.sha256((REF / "manifest.json").read_bytes()).hexdigest() == meta["reference_manifest_sha256"],
            "The reference manifest changed!")
    packets = rdpcap(str(path))
    require(len(packets) == meta["packets"], "Unexpected packet count")
    fragment_count = sum(1 for p in packets if IP in p and (p[IP].frag != 0 or bool(p[IP].flags.MF)))
    if scenario == "T06":
        require(fragment_count >= 2, "Expected several IPv4 fragments")
    else:
        require(fragment_count == 0, "Unexpected IPv4 fragmentation in main experiment")
    results = {}
    for idx, (name, sport, reqfile, respfile) in enumerate(SESSIONS):
        client_seq = 1_000_000 + 100_000 * idx + 1
        server_seq = 2_000_000 + 100_000 * idx + 1
        for direction, src, dst, sp, dp, seq, file in (
            ("request", SENDER, ANALYZER, sport, 8080, client_seq, reqfile),
            ("response", ANALYZER, SENDER, 8080, sport, server_seq, respfile),
        ):
            if scenario == "T06" and name == "large" and direction == "response":
                # Fragmented packets are not ordinary TCP segments before IP reassembly.
                continue
            expected = (REF / "http" / file).read_bytes()
            report = audit_stream(packets, src=src, dst=dst, sport=sp,
                                  dport=dp, initial_seq=seq, expected=expected)
            key = f"{name}_{direction}"
            if scenario == "T05" and key == "large_response":
                require(report["missing_bytes"] > 0, "T05 should have a capture gap")
            else:
                require(report["missing_bytes"] == 0, f"{key} missing bytes")
            results[key] = report
    if scenario == "T03":
        require(results["large_response"]["nonmonotonic_seq_order"],
                "T03 does not contain out-of-order data")
    if scenario == "T04":
        require(results["large_response"]["duplicate_payload_ranges"] >= 1,
                "T04 large response should contain a retransmission")
        require(results["post_request"]["duplicate_payload_ranges"] >= 1,
                "T04 POST request should contain a retransmission")
    if scenario == "T02":
        patterns = {
            "post_request": b"password=TEST_SECRET_2026",
            "basic_request": b"Authorization: Basic bGFidXNlcjpMYWJQYXNzXzIwMjY=",
            "small_response": b"FILE_START_MARKER_SMALL",
            "large_response": b"FILE_START_MARKER_LARGE",
        }
        for key, pattern in patterns.items():
            name, direction = key.split("_", 1)
            row = next(row for row in SESSIONS if row[0] == name)
            sport = row[1]
            src, dst, sp, dp = ((SENDER, ANALYZER, sport, 8080) if direction == "request"
                                else (ANALYZER, SENDER, 8080, sport))
            matching = [bytes(p[TCP].payload) for p in packets
                        if IP in p and TCP in p and p[IP].src == src and p[IP].dst == dst
                        and p[TCP].sport == sp and p[TCP].dport == dp
                        and bytes(p[TCP].payload)]
            require(not any(pattern in payload for payload in matching),
                    f"T02 pattern unexpectedly occurs in a single packet: {key}")
            full = (REF / "http" / (row[2] if direction == "request" else row[3])).read_bytes()
            require(pattern in full, f"Pattern missing in the original stream: {key}")
    print(f"PASS {scenario}: packets={len(packets)}, fragments={fragment_count}")
    for key, report in results.items():
        print(f"  {key:<16} data={report['covered_bytes']}/{report['expected_bytes']}"
              f" missing={report['missing_bytes']} duplicates={report['duplicate_payload_ranges']}"
              f" reordering={report['nonmonotonic_seq_order']}")
    return {"scenario": scenario, "packets": len(packets), "ip_fragments": fragment_count,
            "streams": results}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--include-ipfrag", action="store_true")
    args = parser.parse_args()
    scenarios = ["T00", "T01", "T02", "T03", "T04", "T05"]
    if args.include_ipfrag:
        scenarios.append("T06")
    summaries = [verify_one(s) for s in scenarios]
    # Write one final audit file only after every verification passed.
    output = DIR / "audit_report.json"
    output.write_text(json.dumps(summaries, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("PASS: all selected PCAP files match the declared ground truth where complete")
    print("Wrote", output)


if __name__ == "__main__":
    main()
