#!/usr/bin/env python3
"""Reproducible tcpflow runner for step 4 (T00-T05; optional T06).

Runs two *separate* tcpflow invocations per scenario: raw reconstruction and
HTTP postprocessing. Does not alter PCAPs or reference objects. Existing output
is never removed or overwritten automatically.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PCAPS = ROOT / 'pcaps'
RESULTS = ROOT / 'results' / 'tcpflow'
LOGS = ROOT / 'logs'
BASE_SCENARIOS = [f'T{x:02d}' for x in range(6)]


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def select_scenarios(arg: str) -> list[str]:
    out = [s.strip().upper() for s in arg.split(',') if s.strip()]
    if not out or len(set(out)) != len(out) or any(s not in BASE_SCENARIOS + ['T06'] for s in out):
        raise ValueError('--scenarios must be a comma-separated subset of T00...T06')
    return out


def verify_input(scenario: str):
    pcap = PCAPS / (scenario + '.pcap')
    metadata = PCAPS / (scenario + '.json')
    if not pcap.is_file():
        raise RuntimeError(f'PCAP not found: {pcap}')
    if not metadata.is_file():
        raise RuntimeError(f'PCAP metadata missing: {metadata}')
    expected = json.loads(metadata.read_text(encoding='utf8'))
    actual_hash = digest(pcap)
    if actual_hash != expected.get('pcap_sha256'):
        raise RuntimeError(f'PCAP hash mismatch: {scenario}: {actual_hash}')
    reference_manifest = ROOT / 'reference' / 'manifest.json'
    if not reference_manifest.exists():
        raise RuntimeError('Missing reference/manifest.json')
    if digest(reference_manifest) != expected.get('reference_manifest_sha256'):
        raise RuntimeError(f'Reference manifest differs from fixture in {scenario}')
    return pcap, actual_hash


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scenarios', default=','.join(BASE_SCENARIOS), help='e.g. T00,T01,T02 (T06 optional)')
    parser.add_argument('--skip-http', action='store_true', help='Run only raw flow reconstruction')
    args = parser.parse_args()
    try:
        scenarios = select_scenarios(args.scenarios)
    except ValueError as exc:
        parser.error(str(exc))

    tcpflow = shutil.which('tcpflow')
    if not tcpflow:
        raise SystemExit('ERROR: tcpflow binary not available in PATH; install it on Analyzer')
    version = subprocess.run([tcpflow, '-V'], capture_output=True, text=True, errors='replace')
    LOGS.mkdir(exist_ok=True, parents=True)
    (LOGS / 'tcpflow_version_stage4.txt').write_text(
        (version.stdout + version.stderr).strip() + '\n', encoding='utf8'
    )
    filters = ['tcp port 8080']
    overview = []
    any_failure = False

    for scenario in scenarios:
        try:
            pcap, checksum = verify_input(scenario)
        except Exception as exc:
            print(f'ERROR {scenario}: {exc}', file=sys.stderr)
            return 2
        base = RESULTS / scenario
        base.mkdir(exist_ok=True, parents=True)
        tasks = [('raw', [tcpflow, '-r', str(pcap), '-o', str((base/'raw').resolve()), *filters])]
        if not args.skip_http:
            tasks.append(('http', [tcpflow, '-e', 'http', '-r', str(pcap), '-o', str((base/'http').resolve()), *filters]))
        runs = []
        for label, command in tasks:
            outdir = base / label
            # Refuse to overwrite or mix evidence with preexisting results.
            if outdir.exists() and any(outdir.iterdir()):
                print(f'ERROR: {outdir} is not empty. Move it to a backup before running again.', file=sys.stderr)
                return 3
            outdir.mkdir(parents=True, exist_ok=True)
            print(f'{scenario} [{label}]: tcpflow ...', flush=True)
            completed = subprocess.run(command, capture_output=True, text=True, errors='replace', cwd=str(ROOT))
            combined = (f'$ {" ".join(command)}\nRETURN_CODE={completed.returncode}\n'
                        f'=== STDOUT ===\n{completed.stdout}\n=== STDERR ===\n{completed.stderr}\n')
            (base / (label + '_execution.log')).write_text(combined, encoding='utf8')
            outputs = sorted((str(x.relative_to(base)), x.stat().st_size)
                             for x in outdir.rglob('*') if x.is_file())
            run = {'mode':label,'command':command,'return_code':completed.returncode,'files':outputs}
            runs.append(run)
            if completed.returncode != 0:
                any_failure = True
                print(f'  WARNING: tcpflow returned {completed.returncode}. See {base/(label+"_execution.log")}.')
            else:
                print(f'  done, {len(outputs)} output files')
        record = {'scenario':scenario, 'pcap_sha256':checksum,
                  'tcpflow_version':(version.stdout + version.stderr).strip(),
                  'timestamp_utc':datetime.now(timezone.utc).isoformat(),
                  'runs':runs}
        (base / 'run_metadata.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
        overview.append({'scenario':scenario, 'raw_ok':runs[0]['return_code'] == 0,
                         'http_ok':(runs[1]['return_code'] == 0 if len(runs)>1 else None)})
    (RESULTS / 'execution_overview.json').write_text(
        json.dumps(overview, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print('Completed runs; raw results are in results/tcpflow/Txx/raw/.')
    if any_failure:
        print('WARNING: at least one run failed; inspect execution logs before evaluating results.')
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
