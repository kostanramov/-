#!/usr/bin/env python3
"""Independently audit saved evidence, TCP byte coverage and reconstruction gaps.

Only the Python standard library is required. This script does not execute
tcpflow/ngrep or manufacture their output. It reads saved packet and flow bytes.
"""
from __future__ import annotations

from datetime import datetime, timezone
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys

from t06_pcap import (ROOT, REF, ANALYSIS, FLOW_INFO, read_pcap, tcp_view,
                      detect_endpoints, selected_packet, sha256)
from verify_tcpflow import extract_http

SCENARIOS = [f'T{i:02d}' for i in range(6)]
HTTP_DIRECTIONS = [
    ('small', 41001, 'get_small.http', 'response_small.http'),
    ('large', 41002, 'get_large.http', 'response_large.http'),
    ('post', 41003, 'post_credentials.http', 'response_post.http'),
    ('basic', 41004, 'get_basic.http', 'response_basic.http'),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def missing_ranges(mask):
    """Half-open byte intervals whose positions are not present in the PCAP."""
    result = []
    start = None
    for i, covered in enumerate([*mask, 1]):
        if not covered and start is None:
            start = i
        if covered and start is not None:
            result.append([start, i])
            start = None
    return result


def coverage(data, *, key, expected):
    packets = [tcp_view(record.data) for record in data.records]
    views = [p for p in packets if p and (p.src, p.sport, p.dst, p.dport) == key]
    syns = {
        (p.sequence + 1) % 2**32
        for r in data.records if (p := tcp_view(r.data))
        and (p.src, p.sport, p.dst, p.dport) == key
        and p.flags & 2
    }
    require(len(syns) == 1, f'Need one SYN sequence for {key}')
    base = syns.pop()
    mask = bytearray(len(expected))
    observed = bytearray(len(expected))
    for packet in views:
        if not packet.payload:
            continue
        start = (packet.sequence - base) % 2**32
        end = start + len(packet.payload)
        require(end <= len(expected), f'Payload outside fixture for {key}')
        for index, value in enumerate(packet.payload, start):
            require(not mask[index] or observed[index] == value,
                    f'Conflicting overlap at {index}')
            require(value == expected[index], f'Observed byte differs at {index}')
            observed[index] = value
            mask[index] = 1
    header, separator, _ = expected.partition(b'\r\n\r\n')
    require(separator, 'Reference HTTP delimiter missing')
    body_start = len(header) + 4
    report = {
        'message_length': len(expected), 'message_observed': sum(mask),
        'message_coverage': sum(mask) / len(mask),
        'message_missing_ranges': missing_ranges(mask),
        'body_length': len(mask) - body_start,
        'body_observed': sum(mask[body_start:]),
        'body_coverage': sum(mask[body_start:]) / (len(mask) - body_start)
                         if len(mask) > body_start else None,
        'body_missing_ranges': missing_ranges(mask[body_start:]),
        'syn_payload_start': base,
    }
    return report


def main():
    manifest = json.loads((REF / 'manifest.json').read_text())
    for artifact in manifest['artifacts']:
        path = REF / artifact['path']
        require(path.stat().st_size == artifact['bytes'], f'Changed size {path}')
        require(sha256(path) == artifact['sha256'], f'Changed hash {path}')
    scenarios = SCENARIOS.copy()
    if (ROOT / 'pcaps/T06_snaplen.pcap').exists():
        scenarios.append('T06_snaplen')
    rows = []
    detailed = {}
    for scenario in scenarios:
        source = ROOT / 'pcaps' / (scenario + '.pcap')
        metadata = json.loads(source.with_suffix('.json').read_text())
        require(sha256(source) == metadata['pcap_sha256'], f'Changed PCAP {scenario}')
        data = read_pcap(source)
        sender, analyzer = detect_endpoints(data)
        streams = {}
        for case, port, request, response in HTTP_DIRECTIONS:
            for direction, name, key in (
                ('request', request, (sender, port, analyzer, 8080)),
                ('response', response, (analyzer, 8080, sender, port)),
            ):
                streams[f'{case}_{direction}'] = coverage(
                    data, key=key, expected=(REF / 'http' / name).read_bytes())
        detailed[scenario] = {
            'pcap_sha256': sha256(source), 'packet_count': len(data.records),
            'truncated_records': sum(r.captured_len < r.original_len for r in data.records),
            'streams': streams,
        }
        for case, (port, direction, _, object_id) in FLOW_INFO.items():
            value = streams[f'{case}_{direction}']
            rows.append({
                'scenario': scenario, 'object_id': object_id,
                'coverage_unit': 'HTTP body' if case in ('small', 'large') else 'HTTP message',
                'observed_bytes': value['body_observed'] if case in ('small', 'large') else value['message_observed'],
                'expected_bytes': value['body_length'] if case in ('small', 'large') else value['message_length'],
                'coverage': value['body_coverage'] if case in ('small', 'large') else value['message_coverage'],
                'missing_ranges': json.dumps(value['body_missing_ranges'] if case in ('small', 'large') else value['message_missing_ranges']),
            })
    # Locate damage directly in the saved ALT tcpflow output for T05.
    raw = ROOT / 'results/tcpflow/T05/raw/192.168.056.020.08080-192.168.056.010.41002'
    body = extract_http(raw.read_bytes())[2]
    expected = (REF / 'large.bin').read_bytes()
    require(len(body) == len(expected), 'Unexpected T05 candidate length')
    missing = detailed['T05']['streams']['large_response']['body_missing_ranges']
    start, end = missing[0]
    require(missing == [[11579, 13039]], 'Unexpected T05 gap')
    require(body[start:end] == bytes(end-start), 'Expected zero-filled T05 gap')
    require(body[:start] == expected[:start] and body[end:] == expected[end:],
            'Differences outside T05 missing interval')
    details = {
        'candidate_length': len(body), 'observed_body_bytes': len(expected)-(end-start),
        'missing_body_ranges': missing,
        'differing_positions': sum(a != b for a, b in zip(body, expected)),
        'coincidental_zero_matches': expected[start:end].count(0),
        'candidate_sha256': hashlib.sha256(body).hexdigest(),
    }
    result = {
        'status': 'PASS', 'audit_utc': datetime.now(timezone.utc).isoformat(),
        'verification_host': platform.platform(), 'python': platform.python_version(),
        'mode': 'offline audit of saved evidence, no new ALT tool execution',
        'scenarios': detailed, 'T05_candidate': details,
    }
    ANALYSIS.mkdir(exist_ok=True)
    (ANALYSIS/'independent_audit.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    with (ANALYSIS/'coverage.csv').open('w', newline='', encoding='utf8') as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for row in rows:
        print(f"{row['scenario']} {row['object_id']}: {row['observed_bytes']}/{row['expected_bytes']} = {row['coverage']:.8%}")
    print('PASS: independent PCAP coverage audit and T05 byte comparison')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, IndexError) as error:
        print('ERROR:', error, file=sys.stderr)
        raise SystemExit(2)
