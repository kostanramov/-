#!/usr/bin/env python3
"""Run tcpflow (raw and HTTP) and ngrep (4 literal patterns) only on T06_snaplen.

Does not overwrite any previous T00..T05/T06 results. Requires valid audited T06.
Uses ngrep's -O matching-packet PCAP to avoid fragile textual counts.
"""
from __future__ import annotations
import base64
import json
import argparse
import shutil
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path
from t06_pcap import ROOT,REF,RESULTS,OUT,META,sha256,read_pcap

TARGET='T06_snaplen'


def patterns():
    cred=json.loads((REF/'credentials.json').read_text(encoding='utf8'))
    basic=('Authorization: Basic ').encode('ascii')+base64.b64encode((cred['basic']['username']+':'+cred['basic']['password']).encode())
    post=('password='+cred['form']['password']).encode('ascii')
    return {
        'small':('FILE_START_MARKER_SMALL','tcp src port 8080 and tcp dst port 41001'),
        'large':('FILE_START_MARKER_LARGE','tcp src port 8080 and tcp dst port 41002'),
        'post':(post.decode('ascii'),'tcp src port 41003 and tcp dst port 8080'),
        'basic':(basic.decode('ascii'),'tcp src port 41004 and tcp dst port 8080'),
    }


def execute(cmd:list[str], log_dir:Path, stem:str, allowed:set[int]={0})->int:
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,errors='replace')
    (log_dir/(stem+'.stdout.txt')).write_text(p.stdout,encoding='utf8')
    (log_dir/(stem+'.stderr.txt')).write_text(p.stderr,encoding='utf8')
    if p.returncode not in allowed:
        raise RuntimeError(f'{stem}: {cmd[0]} return code {p.returncode}; inspect {log_dir/(stem+".stderr.txt")}')
    return p.returncode


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--tcpflow',default=None,help='Path to tcpflow executable')
    cli.add_argument('--ngrep',default=None,help='Path to ngrep executable')
    args=cli.parse_args()
    tcpflow=args.tcpflow or shutil.which('tcpflow')
    ngrep=args.ngrep or shutil.which('ngrep')
    if not tcpflow or not ngrep:
        raise RuntimeError('tcpflow and ngrep required (use --tcpflow /path and --ngrep /path if needed)')
    meta=json.loads(META.read_text(encoding='utf8'))
    if meta.get('scenario_variant')!='snaplen_truncation' or sha256(OUT)!=meta['pcap_sha256']:
        raise ValueError('Source T06 snaplen PCAP has changed or wrong metadata; run check_t06_snaplen.py')
    # Validation must already have completed successfully.
    audit=ROOT/'analysis'/'T06_snaplen_capture_audit.json'
    if not audit.exists() or json.loads(audit.read_text(encoding='utf8')).get('output_sha256')!=meta['pcap_sha256']:
        raise ValueError('Capture audit is missing or stale. Run check_t06_snaplen.py first.')
    tcpdir=RESULTS/'tcpflow'/TARGET
    ngdir=RESULTS/'ngrep'/TARGET
    for d in (tcpdir,ngdir):
        if d.exists() and any(d.iterdir()):
            raise FileExistsError(f'{d} nonempty: rename it for independent rerun; previous evidence is preserved')
    tcpdir.mkdir(parents=True,exist_ok=True)
    ngdir.mkdir(parents=True,exist_ok=True)
    info={'scenario':'T06','variant':'snaplen_truncation','pcap_sha256':meta['pcap_sha256'],
          'datetime_utc':datetime.now(timezone.utc).isoformat(),'tcpflow':{},'ngrep':{}}
    version=subprocess.run([tcpflow,'-V'],capture_output=True,text=True,errors='replace')
    info['tcpflow_version']=(version.stdout+version.stderr).strip()
    version=subprocess.run([ngrep,'-V'],capture_output=True,text=True,errors='replace')
    info['ngrep_version']=(version.stdout+version.stderr).strip()
    # -r input -o out & BPF, no shell interpretation.
    for mode in ('raw','http'):
        folder=tcpdir/mode
        folder.mkdir()
        cmd=[tcpflow]
        if mode=='http':
            cmd+=['-e','http']
        cmd+=['-r',str(OUT),'-o',str(folder),'tcp port 8080']
        code=execute(cmd,tcpdir,mode)
        info['tcpflow'][mode]={'cmd':cmd,'return_code':code,'files':[x.name for x in folder.iterdir() if x.is_file()]}
        print(f'tcpflow {mode}: return_code={code}; files={len(info["tcpflow"][mode]["files"])}')
    for key,(pattern,bpf) in patterns().items():
        dest=ngdir/key
        dest.mkdir()
        match_file=dest/'full_matched.pcap'
        cmd=[ngrep,'-q','-I',str(OUT),'-W','byline','-O',str(match_file),pattern,bpf]
        code=execute(cmd,dest,'full',allowed={0,1})
        info['ngrep'][key]={'pattern':pattern,'bpf':bpf,'command':cmd,'return_code':code,'matched_pcap':str(match_file.relative_to(ROOT))}
        print(f'ngrep {key}: return_code={code}; inspect matched PCAP to establish detection')
    (tcpdir/'run_metadata.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    (ngdir/'run_metadata.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('PASS: T06 analysis completed; results in',tcpdir,'and',ngdir)

if __name__=='__main__':
    try: main()
    except (OSError,ValueError,RuntimeError) as exc:
        print('ERROR:',exc,file=sys.stderr)
        sys.exit(2)
