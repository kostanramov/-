#!/usr/bin/env python3
"""Negative controls for HTTP parsing and ngrep evidence verification."""
import importlib.util,json,sys,tempfile
from pathlib import Path
scripts=Path(__file__).resolve().parent
sys.path.insert(0,str(scripts))
from verify_tcpflow import extract_http,check_credentials
from verify_ngrep import inspect_case
from ngrep_lab import get_tests,metadata,packets,PCAPS,OUT
from copy import deepcopy
cases=[
 ('separator_missing',b'HTTP/1.1 200 OK\r\nContent-Length: 2\r\nXX'),
 ('body_short',b'HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nAB'),
 ('body_extra',b'HTTP/1.1 200 OK\r\nContent-Length: 1\r\n\r\nAB'),
 ('duplicate_length',b'HTTP/1.1 200 OK\r\nContent-Length: 1\r\nContent-Length: 1\r\n\r\nA'),
 ('chunked',b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n'),
 ('gzip',b'HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\nContent-Length: 1\r\n\r\nA'),
 ('folded_header',b'HTTP/1.1 200 OK\r\n folded: x\r\n\r\n'),
]
rows=[]
for name,message in cases:
 try:extract_http(message)
 except ValueError:rows.append({'test':name,'status':'PASS'})
 else:raise AssertionError(name)
test=get_tests()[0]
meta=metadata('T02')
original=packets(PCAPS/'T02.pcap')
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)
 src=OUT/'T02'/test.key
 import shutil
 for f in src.glob('full*'):shutil.copy(f,root/f.name)
 record={'exit_code':0}
 assert inspect_case(root,'full',test,meta,original,record)==0
 rows.append({'test':'empty_ngrep_pcap_rc0','status':'PASS'})
 for name,operation in [
  ('missing_matched_pcap', lambda:(root/'full_matched.pcap').unlink()),
  ('damaged_pcap_header', lambda:(root/'full_matched.pcap').write_bytes(b'BAD')),
  ('process_error_rc2', lambda:record.update(exit_code=2)),
  ('nonempty_stderr', lambda:(root/'full.stderr.txt').write_text('error')),
 ]:
  for f in src.glob('full*'):shutil.copy(f,root/f.name)
  record={'exit_code':0}
  operation()
  try:inspect_case(root,'full',test,meta,original,record)
  except ValueError:rows.append({'test':name,'status':'PASS'})
  else:raise AssertionError(name)
path=scripts.parent/'analysis/regression_checks.json'
path.write_text(json.dumps({'status':'PASS','cases':rows},indent=2)+'\n')
print(len(rows),'regression cases passed')
